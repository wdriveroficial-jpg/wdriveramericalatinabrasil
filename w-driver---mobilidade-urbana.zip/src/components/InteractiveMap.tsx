import React, { useState } from 'react';
import { Crosshair, ShieldAlert, Navigation2, MapPin, Sparkles } from 'lucide-react';

interface InteractiveMapProps {
  origem: string;
  destino: string;
  distanciaKm: number;
  tempoMin: number;
  valorEstimado: number;
  onSosClick?: () => void;
  className?: string;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  origem,
  destino,
  distanciaKm,
  tempoMin,
  valorEstimado,
  onSosClick,
  className = '',
}) => {
  const [showSosModal, setShowSosModal] = useState(false);
  const [gpsCentered, setGpsCentered] = useState(true);

  return (
    <div className={`relative w-full h-72 sm:h-80 rounded-2xl overflow-hidden border border-neutral-800/80 bg-[#0c1214] shadow-inner select-none ${className}`}>
      {/* MAP BACKGROUND SVG: João Pessoa geography */}
      <svg
        viewBox="0 0 500 320"
        className="w-full h-full object-cover"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <radialGradient id="oceanGlow" cx="100%" cy="50%" r="60%">
            <stop offset="0%" stopColor="#082f49" stopOpacity="0.7" />
            <stop offset="60%" stopColor="#0c1a24" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#080c10" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="routeGlow" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38bdf8" />
            <stop offset="50%" stopColor="#a3e635" />
            <stop offset="100%" stopColor="#4ade80" />
          </linearGradient>
          <filter id="neonRoute" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Ocean Coastline (Atlantic Ocean East of João Pessoa) */}
        <rect x="420" y="0" width="80" height="320" fill="url(#oceanGlow)" />
        <path
          d="M 430 0 Q 420 80 435 160 T 425 240 T 440 320 L 500 320 L 500 0 Z"
          fill="#0c2333"
          opacity="0.5"
        />

        {/* Road Grid Network */}
        <g stroke="#1a252c" strokeWidth="2" opacity="0.6">
          <line x1="40" y1="40" x2="440" y2="40" />
          <line x1="20" y1="100" x2="420" y2="100" />
          <line x1="30" y1="160" x2="430" y2="160" stroke="#24343d" strokeWidth="3" />
          <line x1="10" y1="220" x2="435" y2="220" />
          <line x1="50" y1="280" x2="440" y2="280" />

          <line x1="90" y1="20" x2="90" y2="300" />
          <line x1="170" y1="10" x2="170" y2="310" stroke="#24343d" strokeWidth="2.5" />
          <line x1="260" y1="15" x2="260" y2="300" stroke="#24343d" strokeWidth="2.5" />
          <line x1="350" y1="25" x2="350" y2="305" />
        </g>

        {/* Curving Avenues (Av. Epitácio Pessoa / BR-230 / Ruy Carneiro) */}
        <path
          d="M 30 180 Q 150 170 260 140 T 430 110"
          fill="none"
          stroke="#1e3a47"
          strokeWidth="6"
          strokeLinecap="round"
        />
        <path
          d="M 120 30 Q 180 140 220 290"
          fill="none"
          stroke="#1e3a47"
          strokeWidth="5"
          strokeLinecap="round"
        />

        {/* City Neighborhood Labels */}
        <g fill="#94a3b8" fontSize="10" fontWeight="700" fontFamily="sans-serif" letterSpacing="0.8">
          <text x="75" y="70">BANCÁRIOS</text>
          <text x="220" y="80">MARUARÁ</text>
          <text x="340" y="125">TAMBAÚ</text>
          <text x="360" y="245">CABO BRANCO</text>
          <text x="90" y="245">TORRE</text>
          <text x="180" y="275">BRISAMAR</text>
        </g>

        {/* Primary City Centered Watermark */}
        <text
          x="235"
          y="200"
          fill="#334155"
          fontSize="13"
          fontWeight="900"
          letterSpacing="2"
          textAnchor="middle"
        >
          JOÃO PESSOA
        </text>

        {/* ACTIVE ROUTE LINE (Neon green/cyan connecting points) */}
        {/* Glow halo */}
        <path
          d="M 85 140 C 130 140, 180 195, 230 175 S 330 135, 385 115"
          fill="none"
          stroke="#a3e635"
          strokeWidth="7"
          strokeLinecap="round"
          opacity="0.3"
          filter="url(#neonRoute)"
        />
        {/* Main sharp line */}
        <path
          d="M 85 140 C 130 140, 180 195, 230 175 S 330 135, 385 115"
          fill="none"
          stroke="url(#routeGlow)"
          strokeWidth="3.5"
          strokeLinecap="round"
        />

        {/* Animated flow dots along route */}
        <path
          d="M 85 140 C 130 140, 180 195, 230 175 S 330 135, 385 115"
          fill="none"
          stroke="#ffffff"
          strokeWidth="2.5"
          strokeDasharray="6 14"
          strokeLinecap="round"
          className="animate-pulse"
        />

        {/* Origin Pin (Blue pulsing beacon) */}
        <g transform="translate(85, 140)">
          <circle r="16" fill="#38bdf8" opacity="0.25" className="animate-ping" />
          <circle r="9" fill="#0284c7" stroke="#ffffff" strokeWidth="2.5" />
          <circle r="3.5" fill="#ffffff" />
        </g>

        {/* Destination Pin (Lime Green Pin) */}
        <g transform="translate(385, 115)">
          <circle r="18" fill="#a3e635" opacity="0.2" className="animate-pulse" />
          <path
            d="M 0 -18 C -7 -18 -12 -12 -12 -5 C -12 4 0 14 0 14 C 0 14 12 4 12 -5 C 12 -12 7 -18 0 -18 Z"
            fill="#a3e635"
            stroke="#0a0a0a"
            strokeWidth="1.5"
          />
          <circle cy="-7" r="4" fill="#0a0a0a" />
        </g>

        {/* Moving Driver Vehicle Marker on Route */}
        <g transform="translate(230, 175)">
          <circle r="12" fill="#0a0a0a" stroke="#a3e635" strokeWidth="2" />
          <polygon points="-4,-4 5,0 -4,4" fill="#a3e635" transform="rotate(-15)" />
        </g>
      </svg>

      {/* FLOATING CONTROLS RIGHT: Target & SOS */}
      <div className="absolute top-3 right-3 flex flex-col gap-2 z-10">
        <button
          onClick={() => setGpsCentered(!gpsCentered)}
          className={`p-2.5 rounded-xl border backdrop-blur-md shadow-lg transition-all ${
            gpsCentered
              ? 'bg-[#1a2e05]/80 border-[#a3e635] text-[#a3e635]'
              : 'bg-neutral-900/80 border-neutral-700 text-neutral-300'
          }`}
          title="Centralizar GPS"
        >
          <Crosshair className="w-5 h-5" />
        </button>

        <button
          onClick={() => {
            setShowSosModal(true);
            onSosClick?.();
          }}
          className="p-2.5 rounded-xl border border-red-500/50 bg-red-950/70 hover:bg-red-900/90 text-red-400 backdrop-blur-md shadow-lg transition-all flex items-center justify-center group"
          title="W-SOS Segurança 24h"
        >
          <div className="flex flex-col items-center">
            <ShieldAlert className="w-5 h-5 text-red-400 group-hover:scale-110 transition-transform" />
            <span className="text-[8px] font-black text-red-300 tracking-tighter">W SOS</span>
          </div>
        </button>
      </div>

      {/* FLOATING TOP BADGE: CURRENT ROUTE HINT */}
      <div className="absolute top-3 left-3 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/75 backdrop-blur-md border border-neutral-800 text-xs text-neutral-300 z-10 shadow-md max-w-[70%] truncate">
        <Navigation2 className="w-3.5 h-3.5 text-[#a3e635] shrink-0 fill-[#a3e635]" />
        <span className="truncate font-medium">{origem.split(',')[0]} ➔ {destino.split(',')[0]}</span>
      </div>

      {/* FLOATING BOTTOM ESTIMATE PILL (From reference screenshot: 15 min • 5,2 km • R$ 7,00 Estimado) */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 w-[92%] max-w-sm z-10">
        <div className="flex items-center justify-between px-4 py-2.5 bg-neutral-950/90 backdrop-blur-md border border-neutral-800 rounded-xl shadow-2xl text-xs font-semibold">
          <div className="flex items-center gap-3 text-neutral-200">
            <span className="flex items-center gap-1 text-[#a3e635] font-bold">
              <span className="inline-block w-2 h-2 rounded-full bg-[#a3e635] animate-ping" />
              {tempoMin} min
            </span>
            <span className="text-neutral-500">•</span>
            <span>{distanciaKm.toFixed(1)} km</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[#a3e635] font-extrabold text-sm">
              R$ {valorEstimado.toFixed(2).replace('.', ',')}
            </span>
            <span className="text-[10px] text-neutral-400 font-normal">Estimado</span>
          </div>
        </div>
      </div>

      {/* W-SOS MODAL */}
      {showSosModal && (
        <div className="absolute inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-neutral-900 border border-red-500/40 rounded-2xl p-5 max-w-xs text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-red-950/80 border border-red-500/60 flex items-center justify-center mx-auto mb-3">
              <ShieldAlert className="w-7 h-7 text-red-400 animate-pulse" />
            </div>
            <h4 className="text-white font-extrabold text-base mb-1">Central W-SOS 24h</h4>
            <p className="text-neutral-300 text-xs mb-4 leading-relaxed">
              Monitoramento telemetria ativo em João Pessoa. Rota rastreada em tempo real e canal direto com a polícia (190) e suporte oficial W-DRIVER.
            </p>
            <div className="flex flex-col gap-2">
              <button
                onClick={() => {
                  alert('Central W-SOS notificada. Seu trajeto e dados foram reforçados no radar da central.');
                  setShowSosModal(false);
                }}
                className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg"
              >
                Disparar Alerta para Central
              </button>
              <button
                onClick={() => setShowSosModal(false)}
                className="w-full py-2 rounded-xl bg-neutral-800 text-neutral-400 hover:text-white text-xs font-semibold"
              >
                Fechar / Voltar à Viagem
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
