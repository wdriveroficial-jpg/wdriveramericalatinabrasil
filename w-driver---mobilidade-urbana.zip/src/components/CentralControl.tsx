import React, { useState } from 'react';
import { Building2, CheckCircle2, Clock, AlertTriangle, ShieldCheck, UserCheck, ArrowRight, DollarSign, Activity, Zap, Ban, ShieldAlert, FileText } from 'lucide-react';
import { RideData, UserRegistration } from '../types';

interface CentralControlProps {
  rides: RideData[];
  onApproveAndDispatch: (rideId: string) => void;
  onGoToDriverRadar: () => void;
  surgeMultiplier?: number;
  onChangeSurgeMultiplier?: (val: number) => void;
  registration?: UserRegistration;
  onUpdateRegistration?: (data: Partial<UserRegistration>) => void;
}

export const CentralControl: React.FC<CentralControlProps> = ({
  rides,
  onApproveAndDispatch,
  onGoToDriverRadar,
  surgeMultiplier = 1.0,
  onChangeSurgeMultiplier,
  registration,
  onUpdateRegistration,
}) => {
  const [bannedCpfs, setBannedCpfs] = useState<string[]>(['123.456.789-99 (Fraude No-Show)', '987.654.321-11 (Tentativa de Calote)']);
  const [newBanCpf, setNewBanCpf] = useState('');
  const [auditMessage, setAuditMessage] = useState<string | null>(null);

  const pendingRides = rides.filter(
    (r) => r.status === 'solicitada' || r.status === 'aguardando_pix' || r.status === 'paga_central'
  );
  const activeRides = rides.filter(
    (r) => r.status === 'despachada' || r.status === 'motorista_a_caminho' || r.status === 'motorista_no_local' || r.status === 'em_viagem'
  );
  const completedRides = rides.filter((r) => r.status === 'concluida');

  const totalFaturado = rides
    .filter((r) => r.status === 'concluida' || r.status === 'paga_central' || r.status === 'em_viagem')
    .reduce((acc, r) => acc + r.valorTotal, 0);

  const totalRepasse = rides
    .filter((r) => r.status === 'concluida' || r.status === 'paga_central' || r.status === 'em_viagem')
    .reduce((acc, r) => acc + r.repasseMotorista, 0);

  const handleBanCpf = () => {
    if (!newBanCpf.trim()) return;
    setBannedCpfs([...bannedCpfs, `${newBanCpf.trim()} (Bloqueio Preventivo)`]);
    setNewBanCpf('');
    setAuditMessage('🚫 CPF e ID de aparelho incluídos na lista negra definitiva!');
    setTimeout(() => setAuditMessage(null), 4000);
  };

  const handleApproveRegistration = () => {
    if (onUpdateRegistration) {
      onUpdateRegistration({ status: 'aprovado' });
      setAuditMessage('✅ Cadastro APROVADO pela Central! Certidões e Biometria validadas com sucesso.');
      setTimeout(() => setAuditMessage(null), 4000);
    }
  };

  const handleRejectRegistration = () => {
    if (onUpdateRegistration) {
      onUpdateRegistration({ status: 'bloqueado' });
      setAuditMessage('⛔ Cadastro BLOQUEADO por inconsistência documental ou antecedentes.');
      setTimeout(() => setAuditMessage(null), 4000);
    }
  };

  return (
    <div className="w-full space-y-5">
      {/* Top Banner: Central 24h Overview */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-white">Central de Controle 24h</h2>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                Operação João Pessoa
              </span>
            </div>
            <p className="text-xs text-neutral-400">
              Despacho operacional, auditoria de pagamentos PIX e liberação direta para o Radar
            </p>
          </div>
        </div>

        {/* Quick KPI stats */}
        <div className="grid grid-cols-3 gap-2 w-full md:w-auto">
          <div className="px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-center">
            <div className="text-[10px] text-neutral-400 font-medium">Aguardando</div>
            <div className="text-base font-black text-amber-400">{pendingRides.length}</div>
          </div>
          <div className="px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-center">
            <div className="text-[10px] text-neutral-400 font-medium">Em Andamento</div>
            <div className="text-base font-black text-sky-400">{activeRides.length}</div>
          </div>
          <div className="px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-center">
            <div className="text-[10px] text-neutral-400 font-medium">Concluídas</div>
            <div className="text-base font-black text-[#a3e635]">{completedRides.length}</div>
          </div>
        </div>
      </div>

      {/* SELETOR DE DINÂMICA REGIONAL DE TARIFA */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#a3e635]" />
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Seletor de Dinâmica Regional de Tarifa
              </h3>
              <p className="text-[11px] text-neutral-400">
                Ajuste da tarifa do radar conforme chuva ou demanda em João Pessoa
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-xl bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635] text-xs font-black">
            Atual: {surgeMultiplier}x
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            { label: 'Normal (1.0x)', val: 1.0, desc: 'Tempo limpo' },
            { label: 'Atenção (1.5x)', val: 1.5, desc: 'Horário de pico' },
            { label: 'Chuva (2.0x)', val: 2.0, desc: 'Pistas molhadas' },
            { label: 'Temporal (3.5x)', val: 3.5, desc: 'Demanda máxima' },
          ].map((item) => (
            <button
              key={item.val}
              type="button"
              onClick={() => onChangeSurgeMultiplier && onChangeSurgeMultiplier(item.val)}
              className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                surgeMultiplier === item.val
                  ? 'bg-[#1a2e05] border-[#a3e635] text-[#a3e635] shadow-[0_0_12px_rgba(163,230,53,0.25)]'
                  : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700 text-neutral-300'
              }`}
            >
              <div className="text-xs font-black">{item.label}</div>
              <div className="text-[10px] text-neutral-500">{item.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* PAINEL DE AUDITORIA E SEGURANÇA W-DRIVER */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-xl space-y-4">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-red-400" />
          <div>
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              Painel de Auditoria e Segurança Anti-Fraude
            </h3>
            <p className="text-[11px] text-neutral-400">
              Validação de biometria, certidões e banimento preventivo por CPF e IMEI
            </p>
          </div>
        </div>

        {/* Audit Message Banner */}
        {auditMessage && (
          <div className="p-3 bg-neutral-950 border border-neutral-700 rounded-xl text-xs font-bold text-neutral-200">
            {auditMessage}
          </div>
        )}

        {/* Registration Approval Section */}
        {registration && (
          <div className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-[#a3e635]" />
                Auditoria de Cadastro de Usuário / Motorista
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                registration.status === 'aprovado'
                  ? 'bg-emerald-500/20 text-emerald-400'
                  : registration.status === 'em_analise'
                  ? 'bg-amber-500/20 text-amber-300'
                  : registration.status === 'bloqueado'
                  ? 'bg-red-500/20 text-red-400'
                  : 'bg-neutral-800 text-neutral-400'
              }`}>
                Status: {registration.status.toUpperCase()}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-neutral-300">
              <div>
                <span className="text-neutral-500 block text-[10px]">Nome:</span>
                <span className="font-semibold">{registration.nome || 'Carlos Roberto'}</span>
              </div>
              <div>
                <span className="text-neutral-500 block text-[10px]">CPF:</span>
                <span className="font-semibold">{registration.cpf || '042.881.992-01'}</span>
              </div>
              <div>
                <span className="text-neutral-500 block text-[10px]">Assinatura gov.br:</span>
                <span className="text-[#a3e635] font-bold">Autenticada ✅</span>
              </div>
              <div>
                <span className="text-neutral-500 block text-[10px]">Biometria / Antecedentes:</span>
                <span className="text-emerald-400 font-bold">Verificados ✅</span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleApproveRegistration}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Aprovar Cadastro</span>
              </button>
              <button
                type="button"
                onClick={handleRejectRegistration}
                className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
              >
                <Ban className="w-3.5 h-3.5" />
                <span>Recusar e Bloquear</span>
              </button>
            </div>
          </div>
        )}

        {/* Banned List & Input */}
        <div className="space-y-2">
          <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
            Banimento Preventivo Imediato (CPF / IMEI):
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={newBanCpf}
              onChange={(e) => setNewBanCpf(e.target.value)}
              placeholder="Digite o CPF para banir da rede W-DRIVER..."
              className="flex-1 p-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-red-500"
            />
            <button
              type="button"
              onClick={handleBanCpf}
              className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Banir CPF
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5 pt-1">
            {bannedCpfs.map((cpf, idx) => (
              <span key={idx} className="px-2.5 py-1 rounded-lg bg-red-950/60 border border-red-500/30 text-red-300 text-[10px] font-mono">
                {cpf}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Financial Split Summary (90% / 10%) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="p-4 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex items-center justify-between">
          <div>
            <div className="text-xs text-neutral-400">Repasses aos Motoristas (90% via W-BANK)</div>
            <div className="text-2xl font-black text-emerald-400">
              R$ {totalRepasse.toFixed(2).replace('.', ',')}
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-emerald-950/60 text-emerald-400 border border-emerald-500/30">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex items-center justify-between">
          <div>
            <div className="text-xs text-neutral-400">Volume Total Transacionado (Garantia Central)</div>
            <div className="text-2xl font-black text-[#a3e635]">
              R$ {totalFaturado.toFixed(2).replace('.', ',')}
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-lime-950/60 text-[#a3e635] border border-[#a3e635]/30">
            <Activity className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* RIDES LIST */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-neutral-200">
            Corridas em Triagem e Despacho
          </h3>
          <button
            onClick={onGoToDriverRadar}
            className="text-xs text-[#a3e635] hover:underline flex items-center gap-1 font-semibold"
          >
            <span>Ver no Radar do Motorista</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {rides.length === 0 ? (
          <div className="p-8 text-center bg-neutral-900/50 border border-neutral-800 rounded-2xl">
            <p className="text-xs text-neutral-400">Nenhuma corrida solicitada no momento.</p>
          </div>
        ) : (
          rides.map((ride) => {
            const isAguardando = ride.status === 'solicitada' || ride.status === 'aguardando_pix';
            const isPaga = ride.status === 'paga_central';
            const isEmAndamento = ['despachada', 'motorista_a_caminho', 'motorista_no_local', 'em_viagem'].includes(ride.status);
            const isConcluida = ride.status === 'concluida';

            return (
              <div
                key={ride.id}
                className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 shadow-md space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-lg bg-neutral-800 text-xs font-bold text-white">
                      {ride.categoria.name}
                    </span>
                    <span className="text-xs text-neutral-400">
                      ID: #{ride.id.slice(-6).toUpperCase()}
                    </span>
                  </div>

                  {/* Status Badge */}
                  <div>
                    {isAguardando && (
                      <span className="px-2.5 py-1 rounded-full bg-amber-950/80 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>Aguardando PIX...</span>
                      </span>
                    )}
                    {isPaga && (
                      <span className="px-2.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>PIX Confirmado pela Central</span>
                      </span>
                    )}
                    {isEmAndamento && (
                      <span className="px-2.5 py-1 rounded-full bg-sky-950/80 border border-sky-500/40 text-sky-300 text-xs font-bold flex items-center gap-1">
                        <Activity className="w-3 h-3 animate-spin" />
                        <span>Em Andamento ({ride.status.replace('_', ' ')})</span>
                      </span>
                    )}
                    {isConcluida && (
                      <span className="px-2.5 py-1 rounded-full bg-lime-950/80 border border-[#a3e635]/40 text-[#a3e635] text-xs font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Finalizada (Repassado)</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Route Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs bg-neutral-950/60 p-3 rounded-xl border border-neutral-800/80">
                  <div>
                    <span className="text-neutral-500 block text-[10px]">Origem (Partida)</span>
                    <span className="text-neutral-200 font-semibold">{ride.origem}</span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-[10px]">Destino (Chegada)</span>
                    <span className="text-neutral-200 font-semibold">{ride.destino}</span>
                  </div>
                </div>

                {/* Price and Split Summary */}
                <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
                  <div className="flex items-center gap-4">
                    <div>
                      <span className="text-neutral-500 text-[10px] block">Valor Passageiro</span>
                      <strong className="text-[#a3e635] text-sm font-extrabold">
                        R$ {ride.valorTotal.toFixed(2).replace('.', ',')}
                      </strong>
                    </div>
                    <div>
                      <span className="text-neutral-500 text-[10px] block">Repasse Motorista (90%)</span>
                      <strong className="text-emerald-300 text-sm font-bold">
                        R$ {ride.repasseMotorista.toFixed(2).replace('.', ',')}
                      </strong>
                    </div>
                    <div>
                      <span className="text-neutral-500 text-[10px] block">Taxa Central (10%)</span>
                      <strong className="text-neutral-400 text-sm font-medium">
                        R$ {ride.taxaPlataforma.toFixed(2).replace('.', ',')}
                      </strong>
                    </div>
                  </div>

                  {/* Central Action Buttons */}
                  <div className="flex items-center gap-2">
                    {ride.status === 'aguardando_pix' && (
                      <button
                        onClick={() => onApproveAndDispatch(ride.id)}
                        className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs transition-colors shadow-md flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Aprovar PIX Manualmente</span>
                      </button>
                    )}

                    {ride.status === 'paga_central' && (
                      <button
                        onClick={() => onApproveAndDispatch(ride.id)}
                        className="px-4 py-2 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-bold text-xs transition-colors shadow-[0_2px_10px_rgba(163,230,53,0.3)] flex items-center gap-1.5"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                        <span>Despachar ao Radar do Motorista</span>
                      </button>
                    )}

                    {isEmAndamento && (
                      <button
                        onClick={onGoToDriverRadar}
                        className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold"
                      >
                        Acompanhar no Radar ➔
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
