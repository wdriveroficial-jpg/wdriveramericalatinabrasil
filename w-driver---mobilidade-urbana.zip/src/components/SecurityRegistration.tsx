import React, { useState } from 'react';
import { 
  ShieldCheck, Lock, UserCheck, FileCheck, CheckCircle2, 
  AlertTriangle, UploadCloud, Camera, Eye, ArrowRight, ShieldAlert 
} from 'lucide-react';
import { UserRegistration, RegistrationStatus } from '../types';
import { TermsModal } from './TermsModal';

interface SecurityRegistrationProps {
  registration: UserRegistration;
  onUpdateRegistration: (data: Partial<UserRegistration>) => void;
  onGoToPassengerApp: () => void;
}

export const SecurityRegistration: React.FC<SecurityRegistrationProps> = ({
  registration,
  onUpdateRegistration,
  onGoToPassengerApp,
}) => {
  const [currentStep, setCurrentStep] = useState<'welcome' | 'form' | 'locked'>('welcome');
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [govBrLoading, setGovBrLoading] = useState(false);

  const handleAssinarGovBr = () => {
    setGovBrLoading(true);
    setTimeout(() => {
      setGovBrLoading(false);
      onUpdateRegistration({ govBrAssinado: true });
    }, 1500);
  };

  const handleSimularUpload = (campo: 'selfie' | 'documento' | 'antecedentes') => {
    if (campo === 'selfie') onUpdateRegistration({ selfieEnviada: true });
    if (campo === 'documento') onUpdateRegistration({ documentoEnviado: true });
    if (campo === 'antecedentes') onUpdateRegistration({ antecedentesEnviados: true });
  };

  const handleEnviarCadastro = () => {
    if (!registration.nome || !registration.cpf) {
      alert('Por favor, informe seu Nome Completo e CPF.');
      return;
    }
    if (!registration.termosAceitos) {
      alert('É necessário aceitar os Termos de Uso e Normas Anti-Calote.');
      return;
    }
    if (!registration.govBrAssinado) {
      alert('É obrigatório assinar digitalmente via gov.br antes de enviar.');
      return;
    }

    onUpdateRegistration({
      status: 'em_analise',
      dataSubmissao: new Date().toLocaleDateString('pt-BR'),
    });
    setCurrentStep('locked');
  };

  const handleAprovarImediatamenteSimulacao = () => {
    onUpdateRegistration({ status: 'aprovado' });
    alert('✅ Cadastro APROVADO pela Central de Segurança W-DRIVER! Corridas liberadas.');
    onGoToPassengerApp();
  };

  return (
    <div className="w-full space-y-4">
      {/* STEP 1: WELCOME SCREEN */}
      {currentStep === 'welcome' && (
        <div className="p-6 rounded-3xl bg-[#121212] border border-neutral-800 shadow-xl space-y-5">
          <div className="w-14 h-14 rounded-2xl bg-[#1a2e05] border border-[#b2ec5d]/50 flex items-center justify-center text-[#b2ec5d]">
            <ShieldCheck className="w-8 h-8" />
          </div>

          <div>
            <span className="text-[10px] font-bold text-[#b2ec5d] uppercase tracking-wider block">
              SISTEMA BLINDADO W-DRIVER
            </span>
            <h2 className="text-xl font-black text-white mt-1">
              Bem-vindo à Mobilidade Segura
            </h2>
            <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
              Transporte legal de passageiros e entregas. Plataforma corporativa blindada contra calotes, fraudes e perfis falsos.
            </p>
          </div>

          <div className="p-3.5 bg-red-950/40 border border-red-500/40 rounded-2xl space-y-1">
            <span className="text-[11px] font-black text-red-300 uppercase tracking-wide flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4" />
              Diretriz de Segurança Rigorosa
            </span>
            <p className="text-[11px] text-neutral-300 leading-normal">
              O uso deste aplicativo exige identificação biométrica facial, documentos oficiais, assinatura digital gov.br e checagem de antecedentes. Pagamento garantido via W-BANK.
            </p>
          </div>

          <button
            onClick={() => setCurrentStep('form')}
            className="w-full py-3.5 rounded-2xl bg-[#b2ec5d] hover:bg-[#9ecf4c] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(178,236,93,0.3)] cursor-pointer flex items-center justify-center gap-2"
          >
            <span>Fazer Cadastro / Validação de Segurança</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* STEP 2: REGISTRATION & VERIFICATION FORM */}
      {currentStep === 'form' && (
        <div className="p-5 sm:p-6 rounded-3xl bg-[#121212] border border-neutral-800 shadow-xl space-y-4">
          <div className="border-b border-neutral-800 pb-3">
            <h2 className="text-base font-black text-[#b2ec5d] uppercase tracking-wide flex items-center gap-2">
              <Lock className="w-4 h-4" />
              Cadastro e Validação de Segurança
            </h2>
            <p className="text-[11px] text-neutral-400 mt-0.5">
              Preencha os dados e anexe os comprovantes oficiais exigidos pela Central.
            </p>
          </div>

          {/* Text Inputs */}
          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1">
                Nome Completo:
              </label>
              <input
                type="text"
                value={registration.nome}
                onChange={(e) => onUpdateRegistration({ nome: e.target.value })}
                placeholder="Seu nome completo (como no documento)"
                className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs focus:border-[#b2ec5d] outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1">
                  CPF:
                </label>
                <input
                  type="text"
                  value={registration.cpf}
                  onChange={(e) => onUpdateRegistration({ cpf: e.target.value })}
                  placeholder="000.000.000-00"
                  className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs focus:border-[#b2ec5d] outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1">
                  Telefone (com DDD):
                </label>
                <input
                  type="text"
                  value={registration.telefone}
                  onChange={(e) => onUpdateRegistration({ telefone: e.target.value })}
                  placeholder="(83) 99999-0000"
                  className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs focus:border-[#b2ec5d] outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1">
                Naturalidade (Cidade/Estado):
              </label>
              <input
                type="text"
                value={registration.naturalidade}
                onChange={(e) => onUpdateRegistration({ naturalidade: e.target.value })}
                placeholder="Ex: João Pessoa / PB"
                className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs focus:border-[#b2ec5d] outline-none"
              />
            </div>
          </div>

          {/* Mandatory Uploads */}
          <div className="pt-2 space-y-3">
            <h3 className="text-xs font-black text-white uppercase tracking-wide">
              Uploads Obrigatórios e Assinatura Digital
            </h3>
            <p className="text-[10px] text-neutral-400">
              Exigimos documentos legíveis, selfie facial de prova de vida e validação governamental oficial.
            </p>

            {/* Upload items */}
            <div className="space-y-2">
              <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Camera className="w-3.5 h-3.5 text-[#b2ec5d]" />
                    Selfie Facial (Prova de Vida)
                  </div>
                  <div className="text-[10px] text-neutral-500">Biometria facial contra contas clonadas</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleSimularUpload('selfie')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    registration.selfieEnviada
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                      : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700'
                  }`}
                >
                  {registration.selfieEnviada ? 'Enviada ✅' : 'Capturar / Anexar'}
                </button>
              </div>

              <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <FileCheck className="w-3.5 h-3.5 text-[#b2ec5d]" />
                    Documento Oficial (RG ou CNH com EAR)
                  </div>
                  <div className="text-[10px] text-neutral-500">Foto frente e verso do documento</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleSimularUpload('documento')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    registration.documentoEnviado
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                      : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700'
                  }`}
                >
                  {registration.documentoEnviado ? 'Enviado ✅' : 'Anexar RG/CNH'}
                </button>
              </div>

              <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#b2ec5d]" />
                    Antecedentes Criminais (Federal + Estadual)
                  </div>
                  <div className="text-[10px] text-neutral-500">Certidões negativas atualizadas</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleSimularUpload('antecedentes')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    registration.antecedentesEnviados
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                      : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700'
                  }`}
                >
                  {registration.antecedentesEnviados ? 'Enviado ✅' : 'Anexar Certidões'}
                </button>
              </div>
            </div>

            {/* Assinatura gov.br */}
            <div className="p-3.5 bg-blue-950/30 border border-blue-500/40 rounded-2xl space-y-2">
              <label className="block text-[11px] font-bold text-blue-300 uppercase tracking-wider">
                Termo de Adesão e Contrato (Assinatura Digital):
              </label>
              <button
                type="button"
                onClick={handleAssinarGovBr}
                disabled={govBrLoading || registration.govBrAssinado}
                className="w-full py-2.5 rounded-xl bg-[#1f6feb] hover:bg-[#388bfd] disabled:bg-neutral-800 text-white font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>
                  {govBrLoading
                    ? 'Conectando ao gov.br...'
                    : registration.govBrAssinado
                    ? 'Assinado via gov.br ✅'
                    : 'Assinar Digitalmente via gov.br'}
                </span>
              </button>
              <p className="text-[10px] text-[#b2ec5d] font-medium">
                {registration.govBrAssinado
                  ? 'Status: Assinado digitalmente via gov.br (Válido e Autenticado ✅)'
                  : 'Status: Aguardando assinatura digital oficial.'}
              </p>
            </div>

            {/* Checkbox Termos */}
            <label className="flex items-start gap-2.5 text-xs text-neutral-300 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={registration.termosAceitos}
                onChange={(e) => onUpdateRegistration({ termosAceitos: e.target.checked })}
                className="mt-0.5 w-4 h-4 rounded accent-[#b2ec5d] cursor-pointer"
              />
              <span className="text-[11px] leading-relaxed">
                Declaro que li e aceito os{' '}
                <span
                  onClick={(e) => {
                    e.preventDefault();
                    setShowTermsModal(true);
                  }}
                  className="text-blue-400 hover:underline font-bold"
                >
                  Termos de Uso, a Política de Privacidade e as Normas de Segurança Anti-Calote
                </span>{' '}
                da W-DRIVER.
              </span>
            </label>
          </div>

          <button
            onClick={handleEnviarCadastro}
            className="w-full py-3.5 rounded-2xl bg-[#b2ec5d] hover:bg-[#9ecf4c] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(178,236,93,0.3)] cursor-pointer mt-2"
          >
            Enviar Documentos para Central
          </button>
        </div>
      )}

      {/* STEP 3: PREVENTATIVE LOCK SCREEN */}
      {currentStep === 'locked' && (
        <div className="p-6 rounded-3xl bg-[#000000] border-2 border-red-500 shadow-2xl text-center space-y-4">
          <div className="w-16 h-16 mx-auto rounded-full bg-red-950/60 border-2 border-red-500 flex items-center justify-center text-red-500">
            <Lock className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-lg font-black text-red-500 uppercase tracking-wider">
              CADASTRO EM ANÁLISE PREVENTIVA
            </h2>
            <p className="text-xs text-white font-bold mt-1">
              Sua biometria, documentos e assinatura gov.br estão sendo validados pela Central W-DRIVER.
            </p>
            <p className="text-[11px] text-neutral-400 mt-2">
              Prazo estimado de auditoria: até 48h. Nenhuma corrida será liberada até a aprovação total das certidões.
            </p>
          </div>

          <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-xl text-left text-xs space-y-1.5">
            <div className="flex justify-between text-neutral-400 text-[11px]">
              <span>Titular:</span>
              <strong className="text-white">{registration.nome || 'Não informado'}</strong>
            </div>
            <div className="flex justify-between text-neutral-400 text-[11px]">
              <span>CPF:</span>
              <strong className="text-white">{registration.cpf || 'Não informado'}</strong>
            </div>
            <div className="flex justify-between text-neutral-400 text-[11px]">
              <span>Assinatura Digital gov.br:</span>
              <strong className="text-emerald-400">Autenticada ✅</strong>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <button
              onClick={handleAprovarImediatamenteSimulacao}
              className="w-full py-3 rounded-xl bg-[#b2ec5d] hover:bg-[#9ecf4c] text-neutral-950 font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
            >
              Simular Aprovação Imediata pela Central
            </button>
            <button
              onClick={() => setCurrentStep('welcome')}
              className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 font-bold text-xs transition-colors cursor-pointer"
            >
              Voltar ao Início
            </button>
          </div>
        </div>
      )}

      {/* Modal dos Termos */}
      <TermsModal
        isOpen={showTermsModal}
        onClose={() => setShowTermsModal(false)}
      />
    </div>
  );
};
