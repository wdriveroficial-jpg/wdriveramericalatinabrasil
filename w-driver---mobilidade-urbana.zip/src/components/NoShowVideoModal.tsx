import React, { useState, useEffect } from 'react';
import { X, Video, Camera, CheckCircle2, RotateCw, ShieldCheck, MapPin, Clock } from 'lucide-react';

interface NoShowVideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmNoShow: () => void;
}

export const NoShowVideoModal: React.FC<NoShowVideoModalProps> = ({
  isOpen,
  onClose,
  onConfirmNoShow,
}) => {
  const [recording, setRecording] = useState(false);
  const [progress, setProgress] = useState(0);
  const [recorded, setRecorded] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (recording && progress < 100) {
      timer = setTimeout(() => {
        setProgress((prev) => prev + 10);
      }, 300);
    } else if (progress >= 100 && recording) {
      setRecording(false);
      setRecorded(true);
    }
    return () => clearTimeout(timer);
  }, [recording, progress]);

  if (!isOpen) return null;

  const handleStartRecording = () => {
    setRecording(true);
    setProgress(0);
    setRecorded(false);
  };

  const handleFinishAndCredit = () => {
    onConfirmNoShow();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-md bg-[#121212] border-2 border-[#b2ec5d] rounded-3xl shadow-[0_0_30px_rgba(178,236,93,0.3)] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-[#000000] px-5 py-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Video className="w-5 h-5 text-[#b2ec5d]" />
            <div>
              <h3 className="text-sm font-black text-[#b2ec5d] uppercase tracking-wider">
                Gravação 360° — Passageiro Ausente
              </h3>
              <p className="text-[10px] text-neutral-400">
                Resguardo de Taxa e Comprovação Jurídica W-DRIVER
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          <div className="relative w-full h-56 bg-neutral-950 rounded-2xl border border-neutral-800 overflow-hidden flex flex-col items-center justify-center">
            {/* Viewfinder elements */}
            <div className="absolute top-3 left-3 flex items-center gap-2 bg-black/70 px-2.5 py-1 rounded-lg border border-neutral-800 text-[10px] font-mono text-neutral-300">
              <span className={`w-2 h-2 rounded-full ${recording ? 'bg-red-500 animate-ping' : 'bg-neutral-600'}`} />
              <span>{recording ? 'GRAVANDO 360°...' : recorded ? 'EVIDÊNCIA SALVA' : 'PRONTO PARA GRAVAR'}</span>
            </div>

            <div className="absolute top-3 right-3 bg-black/70 px-2.5 py-1 rounded-lg border border-neutral-800 text-[10px] font-mono text-[#b2ec5d]">
              03:00 MIN EXPIRADO
            </div>

            {/* Target reticle */}
            <div className="w-24 h-24 rounded-full border border-dashed border-[#b2ec5d]/50 flex items-center justify-center animate-pulse">
              <Camera className="w-8 h-8 text-[#b2ec5d]/70" />
            </div>

            {/* Simulated rotation guidance */}
            <div className="absolute bottom-3 inset-x-3 bg-black/80 px-3 py-1.5 rounded-xl border border-neutral-800 flex items-center justify-between text-[11px] text-neutral-300">
              <span className="flex items-center gap-1.5 text-neutral-400">
                <RotateCw className="w-3.5 h-3.5 text-[#b2ec5d] animate-spin" />
                Gire o celular 360° ao redor do carro
              </span>
              <span className="font-bold text-[#b2ec5d]">{progress}%</span>
            </div>
          </div>

          {/* Guidelines */}
          <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-xl space-y-1.5 text-xs text-neutral-300">
            <div className="flex items-center gap-1.5 font-bold text-white text-[11px]">
              <ShieldCheck className="w-4 h-4 text-[#b2ec5d]" />
              <span>Garantia de Crédito no W-BANK:</span>
            </div>
            <p className="text-[11px] text-neutral-400">
              O vídeo registra automaticamente sua localização GPS, carimbo de tempo e a ausência do usuário no ponto marcado. A taxa integral de deslocamento será creditada na sua carteira W-BANK.
            </p>
          </div>

          {/* Action buttons */}
          {!recorded ? (
            <button
              onClick={handleStartRecording}
              disabled={recording}
              className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-500 disabled:bg-neutral-800 text-white font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <Camera className="w-4 h-4" />
              <span>{recording ? `Gravando (${progress}%)...` : 'Iniciar Gravação 360°'}</span>
            </button>
          ) : (
            <button
              onClick={handleFinishAndCredit}
              className="w-full py-3 rounded-xl bg-[#b2ec5d] hover:bg-[#9ecf4c] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(178,236,93,0.4)]"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Enviar à Central & Creditar Taxa W-BANK</span>
            </button>
          )}

          <button
            onClick={onClose}
            className="w-full py-2 text-neutral-500 hover:text-neutral-300 text-xs font-semibold cursor-pointer"
          >
            Voltar ao Painel
          </button>
        </div>
      </div>
    </div>
  );
};
