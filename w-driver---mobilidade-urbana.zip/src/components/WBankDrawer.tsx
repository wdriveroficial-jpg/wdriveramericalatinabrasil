import React, { useState } from 'react';
import { ArrowLeft, Wallet, ArrowUpRight, ArrowDownLeft, ShieldCheck, CreditCard, Sparkles, CheckCircle2 } from 'lucide-react';
import { WDriverLogo } from './WDriverLogo';
import { RideData } from '../types';

interface WBankDrawerProps {
  onClose: () => void;
  completedRides: RideData[];
}

export const WBankDrawer: React.FC<WBankDrawerProps> = ({
  onClose,
  completedRides,
}) => {
  const [chavePix, setChavePix] = useState('carlos.motorista@email.com');
  const [transferSuccess, setTransferSuccess] = useState(false);
  const [transferring, setTransferring] = useState(false);

  // Sum earnings from completed rides plus initial balance
  const earnedFromRides = completedRides.reduce((acc, r) => acc + r.repasseMotorista, 0);
  const [balance, setBalance] = useState(148.5 + earnedFromRides);

  const handleWithdraw = () => {
    if (balance <= 0) {
      alert('Saldo insuficiente para transferência.');
      return;
    }
    setTransferring(true);
    setTimeout(() => {
      setTransferring(false);
      setTransferSuccess(true);
      setBalance(0);
      setTimeout(() => setTransferSuccess(false), 4000);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-md bg-[#0a0f0a] border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header with W-BANK Logo */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-800 bg-neutral-950">
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <WDriverLogo variant="wbank" size="sm" />
          <div className="w-8" />
        </div>

        <div className="p-5 overflow-y-auto space-y-4">
          {/* Virtual Account Card */}
          <div className="relative p-5 rounded-3xl bg-gradient-to-br from-[#1b3808] via-[#0d1c04] to-[#050b02] border border-[#a3e635]/40 text-white shadow-xl overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
              <WDriverLogo variant="icon" size="xl" />
            </div>

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#a3e635]" />
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                  Conta Corrente Motorista
                </span>
              </div>
              <CreditCard className="w-5 h-5 text-neutral-400" />
            </div>

            <div className="mb-4">
              <span className="text-xs text-neutral-400 block font-medium">Saldo Disponível</span>
              <div className="text-3xl font-black text-[#a3e635] tracking-tight">
                R$ {balance.toFixed(2).replace('.', ',')}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-neutral-400 border-t border-white/10 pt-3">
              <div>
                <span className="text-[10px] block text-neutral-500">Titular</span>
                <span className="font-semibold text-white">Carlos E. da Silva</span>
              </div>
              <div className="text-right">
                <span className="text-[10px] block text-neutral-500">Repasse W-DRIVER</span>
                <span className="font-bold text-[#a3e635]">90% Líquido</span>
              </div>
            </div>
          </div>

          {/* Quick Transfer Form */}
          <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">Saque Instantâneo PIX</span>
              <span className="text-[11px] text-emerald-400 font-semibold">Sem taxas • 24h</span>
            </div>

            <div>
              <label className="text-[11px] text-neutral-400 block mb-1">Chave PIX Cadastrada:</label>
              <input
                type="text"
                value={chavePix}
                onChange={(e) => setChavePix(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-white outline-none focus:border-[#a3e635]"
              />
            </div>

            {transferSuccess ? (
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2 font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Transferência PIX de 90% enviada com sucesso para sua conta bancária!</span>
              </div>
            ) : (
              <button
                onClick={handleWithdraw}
                disabled={transferring || balance <= 0}
                className="w-full py-3 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-md disabled:opacity-40 flex items-center justify-center gap-2 cursor-pointer"
              >
                {transferring ? (
                  <span>Enviando PIX para sua conta...</span>
                ) : (
                  <>
                    <ArrowUpRight className="w-4 h-4" />
                    <span>Transferir Tudo via PIX</span>
                  </>
                )}
              </button>
            )}
          </div>

          {/* Recent Statement / Repasses History */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-neutral-300 block">Extrato de Repasses das Corridas</span>
            
            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <ArrowDownLeft className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-white">Corrida #WD-8402 (W-MOTO)</div>
                    <div className="text-[10px] text-neutral-500">Hoje às 12:15 • Tambaú ➔ Manaíra</div>
                  </div>
                </div>
                <strong className="text-emerald-400 font-extrabold">+ R$ 18,90</strong>
              </div>

              <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <ArrowDownLeft className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-white">Corrida #WD-8391 (W-CARRO)</div>
                    <div className="text-[10px] text-neutral-500">Hoje às 10:40 • Cabo Branco ➔ Bancários</div>
                  </div>
                </div>
                <strong className="text-emerald-400 font-extrabold">+ R$ 37,80</strong>
              </div>

              {completedRides.map((ride) => (
                <div
                  key={ride.id}
                  className="p-3 rounded-xl bg-neutral-900 border border-[#a3e635]/40 flex items-center justify-between animate-fadeIn"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-[#1a2e05] border border-[#a3e635]/50 flex items-center justify-center text-[#a3e635]">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-bold text-white">
                        Corrida #{ride.id.slice(-6).toUpperCase()} ({ride.categoria.name})
                      </div>
                      <div className="text-[10px] text-neutral-400">
                        {ride.origem.split(',')[0]} ➔ {ride.destino.split(',')[0]}
                      </div>
                    </div>
                  </div>
                  <strong className="text-[#a3e635] font-black">
                    + R$ {ride.repasseMotorista.toFixed(2).replace('.', ',')}
                  </strong>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
