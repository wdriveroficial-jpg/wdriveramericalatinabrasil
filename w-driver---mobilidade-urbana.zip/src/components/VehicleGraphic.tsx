import React from 'react';
import { Bike, Crown } from 'lucide-react';

interface VehicleGraphicProps {
  type: 'bike' | 'moto' | 'moto_prime' | 'car_white' | 'car_blue' | 'car_black' | 'car_exec' | 'luxury' | 'taxi';
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const VehicleGraphic: React.FC<VehicleGraphicProps> = ({
  type,
  className = '',
  size = 'md',
}) => {
  const sizeClasses = {
    sm: 'w-10 h-7',
    md: 'w-14 h-9',
    lg: 'w-24 h-14',
  }[size];

  switch (type) {
    case 'bike':
      return (
        <div className={`relative flex items-center justify-center text-amber-400 ${sizeClasses} ${className}`}>
          <Bike className="w-full h-full drop-shadow-[0_2px_8px_rgba(251,191,36,0.5)]" />
        </div>
      );

    case 'moto':
      return (
        <div className={`relative flex items-center justify-center ${sizeClasses} ${className}`}>
          {/* Detailed sport/commuter motorcycle SVG */}
          <svg viewBox="0 0 80 50" className="w-full h-full drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]" fill="none">
            {/* Wheels */}
            <circle cx="18" cy="35" r="11" stroke="#475569" strokeWidth="4" fill="#0f172a" />
            <circle cx="18" cy="35" r="4" fill="#94a3b8" />
            <circle cx="62" cy="35" r="11" stroke="#475569" strokeWidth="4" fill="#0f172a" />
            <circle cx="62" cy="35" r="4" fill="#94a3b8" />
            {/* Frame & Exhaust */}
            <path d="M18 35 L34 26 L50 26 L62 35" stroke="#64748b" strokeWidth="3" strokeLinecap="round" />
            <path d="M30 36 L52 36 L64 30" stroke="#94a3b8" strokeWidth="2.5" />
            {/* Body Tank (Silver/White) */}
            <path d="M30 24 Q38 16 50 20 L44 26 Z" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1" />
            {/* Seat */}
            <path d="M26 24 Q32 22 38 25 L34 27 Z" fill="#1e293b" />
            {/* Handlebar & Windshield */}
            <path d="M48 20 L54 13 L51 12" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
            {/* Headlight */}
            <circle cx="56" cy="18" r="2.5" fill="#fef08a" />
          </svg>
        </div>
      );

    case 'moto_prime':
      return (
        <div className={`relative flex items-center justify-center ${sizeClasses} ${className}`}>
          {/* Lime green sport racing motorcycle SVG */}
          <svg viewBox="0 0 80 50" className="w-full h-full drop-shadow-[0_2px_8px_rgba(163,230,53,0.4)]" fill="none">
            <circle cx="18" cy="35" r="11" stroke="#334155" strokeWidth="4" fill="#090d16" />
            <circle cx="18" cy="35" r="5" stroke="#a3e635" strokeWidth="1.5" fill="#1e293b" />
            <circle cx="62" cy="35" r="11" stroke="#334155" strokeWidth="4" fill="#090d16" />
            <circle cx="62" cy="35" r="5" stroke="#a3e635" strokeWidth="1.5" fill="#1e293b" />
            <path d="M18 35 L34 24 L52 24 L62 35" stroke="#475569" strokeWidth="3.5" />
            {/* Aerodynamic fairing Lime Green */}
            <path d="M28 22 Q40 12 56 16 L52 25 L34 26 Z" fill="#a3e635" />
            <path d="M52 15 L62 20 L55 24 Z" fill="#65a30d" />
            {/* Smoked visor */}
            <path d="M50 14 L56 8 L54 7 Z" fill="#38bdf8" opacity="0.85" />
            {/* Racing Decal */}
            <circle cx="58" cy="18" r="2" fill="#fff" />
          </svg>
        </div>
      );

    case 'car_white':
      return (
        <div className={`relative flex items-center justify-center ${sizeClasses} ${className}`}>
          {/* Crisp White Modern Sedan */}
          <svg viewBox="0 0 90 45" className="w-full h-full drop-shadow-[0_2px_8px_rgba(0,0,0,0.7)]" fill="none">
            {/* Wheels */}
            <circle cx="22" cy="33" r="8" fill="#0f172a" stroke="#475569" strokeWidth="3" />
            <circle cx="22" cy="33" r="3" fill="#cbd5e1" />
            <circle cx="68" cy="33" r="8" fill="#0f172a" stroke="#475569" strokeWidth="3" />
            <circle cx="68" cy="33" r="3" fill="#cbd5e1" />
            {/* Body */}
            <path
              d="M 6 29 C 8 26 14 26 18 24 L 28 14 C 32 12 58 12 63 15 L 75 22 C 82 24 86 26 86 29 L 85 33 C 85 34 83 35 78 35 L 75 35 C 73 30 63 30 61 35 L 29 35 C 27 30 17 30 15 35 L 9 35 C 6 35 5 32 6 29 Z"
              fill="#f1f5f9"
              stroke="#cbd5e1"
              strokeWidth="1.2"
            />
            {/* Windows */}
            <path d="M 30 16 L 46 16 L 46 23 L 22 23 Z" fill="#0284c7" opacity="0.75" />
            <path d="M 49 16 L 60 17 L 70 23 L 49 23 Z" fill="#0284c7" opacity="0.75" />
            {/* Headlights */}
            <path d="M 83 26 L 86 28 L 84 30 Z" fill="#fef08a" />
          </svg>
        </div>
      );

    case 'car_blue':
      return (
        <div className={`relative flex items-center justify-center ${sizeClasses} ${className}`}>
          {/* Blue Prime Modern Sedan */}
          <svg viewBox="0 0 90 45" className="w-full h-full drop-shadow-[0_2px_8px_rgba(37,99,235,0.4)]" fill="none">
            <circle cx="22" cy="33" r="8" fill="#0f172a" stroke="#475569" strokeWidth="3" />
            <circle cx="22" cy="33" r="3" fill="#cbd5e1" />
            <circle cx="68" cy="33" r="8" fill="#0f172a" stroke="#475569" strokeWidth="3" />
            <circle cx="68" cy="33" r="3" fill="#cbd5e1" />
            <path
              d="M 6 29 C 8 26 14 26 18 24 L 28 14 C 32 12 58 12 63 15 L 75 22 C 82 24 86 26 86 29 L 85 33 C 85 34 83 35 78 35 L 75 35 C 73 30 63 30 61 35 L 29 35 C 27 30 17 30 15 35 L 9 35 C 6 35 5 32 6 29 Z"
              fill="#2563eb"
              stroke="#1d4ed8"
              strokeWidth="1.2"
            />
            <path d="M 30 16 L 46 16 L 46 23 L 22 23 Z" fill="#0f172a" opacity="0.85" />
            <path d="M 49 16 L 60 17 L 70 23 L 49 23 Z" fill="#0f172a" opacity="0.85" />
            <path d="M 83 26 L 86 28 L 84 30 Z" fill="#fef08a" />
          </svg>
        </div>
      );

    case 'car_black':
    case 'car_exec':
      return (
        <div className={`relative flex items-center justify-center ${sizeClasses} ${className}`}>
          {/* Executive Black Gloss Sedan */}
          <svg viewBox="0 0 90 45" className="w-full h-full drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]" fill="none">
            <circle cx="22" cy="33" r="8" fill="#020617" stroke="#334155" strokeWidth="3" />
            <circle cx="22" cy="33" r="3" fill="#94a3b8" />
            <circle cx="68" cy="33" r="8" fill="#020617" stroke="#334155" strokeWidth="3" />
            <circle cx="68" cy="33" r="3" fill="#94a3b8" />
            <path
              d="M 6 29 C 8 26 14 26 18 24 L 28 14 C 32 12 58 12 63 15 L 75 22 C 82 24 86 26 86 29 L 85 33 C 85 34 83 35 78 35 L 75 35 C 73 30 63 30 61 35 L 29 35 C 27 30 17 30 15 35 L 9 35 C 6 35 5 32 6 29 Z"
              fill="#18181b"
              stroke="#3f3f46"
              strokeWidth="1.2"
            />
            {/* Chrome beltline */}
            <path d="M 12 26 L 80 26" stroke="#a1a1aa" strokeWidth="0.8" />
            {/* Dark tinted privacy glass */}
            <path d="M 30 16 L 46 16 L 46 23 L 22 23 Z" fill="#09090b" stroke="#27272a" strokeWidth="0.5" />
            <path d="M 49 16 L 60 17 L 70 23 L 49 23 Z" fill="#09090b" stroke="#27272a" strokeWidth="0.5" />
            <path d="M 83 26 L 86 28 L 84 30 Z" fill="#fef08a" />
          </svg>
        </div>
      );

    case 'luxury':
      return (
        <div className={`relative flex items-center justify-center ${sizeClasses} ${className}`}>
          {/* Luxury Limousine / VIP Flagship with Crown */}
          <div className="relative">
            <Crown className="w-4 h-4 text-amber-400 absolute -top-3 left-1/2 -translate-x-1/2 drop-shadow-[0_0_8px_rgba(251,191,36,0.8)]" />
            <svg viewBox="0 0 95 45" className="w-full h-full drop-shadow-[0_2px_10px_rgba(251,191,36,0.3)]" fill="none">
              <circle cx="22" cy="33" r="8" fill="#020617" stroke="#eab308" strokeWidth="2.5" />
              <circle cx="22" cy="33" r="3" fill="#eab308" />
              <circle cx="72" cy="33" r="8" fill="#020617" stroke="#eab308" strokeWidth="2.5" />
              <circle cx="72" cy="33" r="3" fill="#eab308" />
              <path
                d="M 5 29 C 7 26 14 26 18 24 L 28 13 C 32 11 65 11 70 14 L 81 22 C 87 24 91 26 91 29 L 90 33 C 90 34 88 35 83 35 L 79 35 C 77 30 67 30 65 35 L 29 35 C 27 30 17 30 15 35 L 8 35 C 5 35 4 32 5 29 Z"
                fill="#09090b"
                stroke="#eab308"
                strokeWidth="1.5"
              />
              <path d="M 30 15 L 75 15 L 77 22 L 24 22 Z" fill="#18181b" stroke="#713f12" strokeWidth="0.8" />
              <path d="M 88 26 L 91 28 L 89 30 Z" fill="#fef08a" />
            </svg>
          </div>
        </div>
      );

    case 'taxi':
      return (
        <div className={`relative flex items-center justify-center ${sizeClasses} ${className}`}>
          {/* Classic Yellow Taxi with Roof Light */}
          <svg viewBox="0 0 90 48" className="w-full h-full drop-shadow-[0_2px_10px_rgba(234,179,8,0.5)]" fill="none">
            {/* TAXI Roof Sign */}
            <rect x="42" y="7" width="16" height="6" rx="2" fill="#fff" stroke="#ca8a04" strokeWidth="1" />
            <text x="50" y="12" fontSize="4.5" fontWeight="900" fill="#000" textAnchor="middle" fontFamily="sans-serif">TAXI</text>
            
            {/* Wheels */}
            <circle cx="22" cy="36" r="8" fill="#0f172a" stroke="#475569" strokeWidth="3" />
            <circle cx="22" cy="36" r="3" fill="#cbd5e1" />
            <circle cx="68" cy="36" r="8" fill="#0f172a" stroke="#475569" strokeWidth="3" />
            <circle cx="68" cy="36" r="3" fill="#cbd5e1" />

            {/* Yellow Body */}
            <path
              d="M 6 32 C 8 29 14 29 18 27 L 28 16 C 32 14 58 14 63 17 L 75 25 C 82 27 86 29 86 32 L 85 36 C 85 37 83 38 78 38 L 75 38 C 73 33 63 33 61 38 L 29 38 C 27 33 17 33 15 38 L 9 38 C 6 38 5 35 6 32 Z"
              fill="#eab308"
              stroke="#ca8a04"
              strokeWidth="1.2"
            />
            {/* Checker pattern stripe */}
            <path d="M 22 28 L 75 28" stroke="#000" strokeWidth="2.5" strokeDasharray="3 3" />
            {/* Windows */}
            <path d="M 30 18 L 46 18 L 46 25 L 22 25 Z" fill="#38bdf8" opacity="0.6" />
            <path d="M 49 18 L 60 19 L 70 25 L 49 25 Z" fill="#38bdf8" opacity="0.6" />
            {/* Headlights */}
            <path d="M 83 29 L 86 31 L 84 33 Z" fill="#fef08a" />
          </svg>
        </div>
      );

    default:
      return null;
  }
};
