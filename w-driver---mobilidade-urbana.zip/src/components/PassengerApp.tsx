import React, { useState } from 'react';
import { 
  Menu, Bell, User, Star, ArrowUpDown, MapPin, Navigation, 
  Home, Briefcase, Heart, Gift, Compass, Search, ChevronRight,
  Zap, Info, Check, Shield
} from 'lucide-react';
import { CategoryInfo, ServiceCategory } from '../types';
import { CATEGORIES, JOAO_PESSOA_LOCATIONS } from '../data/categories';
import { VehicleGraphic } from './VehicleGraphic';
import { InteractiveMap } from './InteractiveMap';
import { TaxiDetailModal } from './TaxiDetailModal';
import { WDriverLogo } from './WDriverLogo';
import { SosModal } from './SosModal';

interface PassengerAppProps {
  origem: string;
  setOrigem: (val: string) => void;
  destino: string;
  setDestino: (val: string) => void;
  distanciaKm: number;
  setDistanciaKm: (val: number) => void;
  selectedCategory: CategoryInfo;
  setSelectedCategory: (cat: CategoryInfo) => void;
  surgeActive: boolean;
  setSurgeActive: (val: boolean) => void;
  onProceedToPayment: () => void;
}

export const PassengerApp: React.FC<PassengerAppProps> = ({
  origem,
  setOrigem,
  destino,
  setDestino,
  distanciaKm,
  setDistanciaKm,
  selectedCategory,
  setSelectedCategory,
  surgeActive,
  setSurgeActive,
  onProceedToPayment,
}) => {
  const [showSplash, setShowSplash] = useState<boolean>(false);
  const [showTaxiModal, setShowTaxiModal] = useState(false);
  const [showSosModal, setShowSosModal] = useState(false);
  const [viewMode, setViewMode] = useState<'home' | 'all_services'>('home');
  const [activeBottomNav, setActiveBottomNav] = useState<'inicio' | 'explorar' | 'favoritos' | 'perfil'>('inicio');

  // Fare Calculation based on official W-DRIVER rules:
  // Base fixed fare covers up to 4 km. Beyond 4 km, each additional km is multiplied by kmAdicional.
  // Surge multiplier is 3.5x or 2.5x when active.
  const calculateTotal = (cat: CategoryInfo) => {
    let fare = cat.baseFare;
    if (distanciaKm > 4) {
      const extraKm = distanciaKm - 4;
      fare += extraKm * cat.kmAdicional;
    }
    if (surgeActive) {
      fare *= 3.5;
    }
    return Math.round(fare * 100) / 100;
  };

  const currentTotal = calculateTotal(selectedCategory);

  const swapLocations = () => {
    const temp = origem;
    setOrigem(destino);
    setDestino(temp);
  };

  const handleSelectCategory = (cat: CategoryInfo) => {
    setSelectedCategory(cat);
    if (cat.id === 'taxi') {
      setShowTaxiModal(true);
    }
  };

  if (showSplash) {
    return (
      <div className="w-full max-w-md mx-auto bg-gradient-to-b from-[#0a1205] via-[#080c06] to-[#050804] text-neutral-100 rounded-3xl overflow-hidden border border-neutral-800 shadow-2xl flex flex-col justify-between min-h-[680px] p-6 relative select-none animate-fadeIn">
        {/* Ambient green dynamic wave background lines */}
        <div className="absolute inset-0 pointer-events-none opacity-30">
          <svg viewBox="0 0 400 680" className="w-full h-full">
            <path
              d="M -50 400 Q 150 200 450 450"
              fill="none"
              stroke="#a3e635"
              strokeWidth="4"
              opacity="0.3"
            />
            <path
              d="M -30 450 Q 180 250 430 520"
              fill="none"
              stroke="#84cc16"
              strokeWidth="2"
              opacity="0.2"
            />
            <circle cx="200" cy="220" r="140" fill="radial-gradient(circle, rgba(163,230,53,0.15) 0%, transparent 70%)" />
          </svg>
        </div>

        <div className="flex justify-end relative z-10">
          <button
            onClick={() => setShowSplash(false)}
            className="text-xs text-neutral-400 hover:text-white px-3 py-1 rounded-full bg-neutral-900/60 border border-neutral-800"
          >
            Pular tela ➔
          </button>
        </div>

        {/* Center Welcome Graphics and Typography */}
        <div className="relative z-10 flex flex-col items-center text-center space-y-6 my-auto">
          <WDriverLogo variant="splash" size="xl" />

          <div className="space-y-3 max-w-xs">
            <h1 className="text-3xl font-black text-white tracking-tight">
              Bem-vindo!
            </h1>
            <p className="text-sm text-neutral-300 font-medium leading-relaxed">
              Seu destino, nossa prioridade. Viaje com segurança, conforto e praticidade.
            </p>
          </div>
        </div>

        {/* Bottom CTA Button */}
        <div className="relative z-10 pt-4">
          <button
            onClick={() => setShowSplash(false)}
            className="w-full py-4 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] active:scale-[0.99] text-neutral-950 font-black text-base tracking-tight transition-all shadow-[0_4px_24px_rgba(163,230,53,0.4)] flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Começar</span>
            <span className="text-xl leading-none">➔</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-md mx-auto bg-[#0a0a0a] text-neutral-100 rounded-3xl overflow-hidden border border-neutral-800 shadow-2xl flex flex-col min-h-[720px] relative pb-16">
      {/* TOP HEADER: Hamburger Menu, Logo, Profile & Notification Bell with green alert dot */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-800/80 bg-neutral-950/90 sticky top-0 z-30 backdrop-blur-md">
        <button
          onClick={() => setShowSplash(true)}
          className="p-2 -ml-1 text-neutral-300 hover:text-white rounded-xl hover:bg-neutral-900 transition-colors"
          title="Ver Tela de Boas-vindas (Splash)"
        >
          <Menu className="w-6 h-6" />
        </button>

        <button onClick={() => setShowSplash(true)} title="Clique para ver a tela de início">
          <WDriverLogo size="sm" />
        </button>

        <div className="flex items-center gap-1">
          <button className="p-2 text-neutral-300 hover:text-white rounded-xl hover:bg-neutral-900 transition-colors">
            <User className="w-5 h-5" />
          </button>
          <button className="p-2 text-neutral-300 hover:text-white rounded-xl hover:bg-neutral-900 transition-colors relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#a3e635] shadow-[0_0_6px_#a3e635]" />
          </button>
        </div>
      </div>

      {/* BODY SCROLLABLE AREA */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {/* W-SOS EMERGENCY BUTTON */}
        <button
          type="button"
          onClick={() => setShowSosModal(true)}
          className="w-full py-2.5 px-4 rounded-2xl bg-red-600 hover:bg-red-500 active:scale-98 text-white font-black text-xs uppercase tracking-wider shadow-[0_0_16px_rgba(239,68,68,0.4)] transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>🚨 ACIONAR W-SOS (EMERGÊNCIA)</span>
        </button>

        {/* SECURE GPS ROUTE BADGE */}
        <div className="flex items-center justify-center gap-2 py-1.5 px-3 rounded-xl bg-neutral-900/90 border border-neutral-800 text-[11px] text-neutral-300">
          <Shield className="w-3.5 h-3.5 text-[#b2ec5d]" />
          <span>📍 GPS W-DRIVER Ativo — Rota Segura Criptografada</span>
        </div>

        {/* INPUTS: ORIGIN & DESTINATION WITH ICONS */}
        <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 shadow-md space-y-2.5">
          {/* Origin */}
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-full border-2 border-[#a3e635] flex items-center justify-center shrink-0">
              <div className="w-2 h-2 rounded-full bg-[#a3e635]" />
            </div>
            <div className="flex-1">
              <label className="text-[10px] uppercase font-bold text-neutral-400 block tracking-wider">
                De onde você está?
              </label>
              <input
                type="text"
                value={origem}
                onChange={(e) => setOrigem(e.target.value)}
                placeholder="Minha localização"
                className="w-full bg-transparent text-xs font-semibold text-white outline-none placeholder:text-neutral-500"
              />
            </div>
            <button className="px-2.5 py-1 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[11px] font-bold flex items-center gap-1 shrink-0 transition-colors">
              <Star className="w-3 h-3 text-amber-400" />
              <span>Favoritos</span>
            </button>
          </div>

          <div className="border-t border-neutral-800/80 ml-8" />

          {/* Destination */}
          <div className="flex items-center gap-2.5">
            <MapPin className="w-6 h-6 text-[#a3e635] shrink-0 fill-[#a3e635]/20" />
            <div className="flex-1">
              <label className="text-[10px] uppercase font-bold text-neutral-400 block tracking-wider">
                Para onde quer ir?
              </label>
              <input
                type="text"
                value={destino}
                onChange={(e) => setDestino(e.target.value)}
                placeholder="Digite seu destino"
                className="w-full bg-transparent text-xs font-semibold text-white outline-none placeholder:text-neutral-500"
              />
            </div>
            <button
              onClick={swapLocations}
              className="p-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white shrink-0 transition-colors"
              title="Inverter origem e destino"
            >
              <ArrowUpDown className="w-4 h-4 text-[#a3e635]" />
            </button>
          </div>

          {/* Distance Slider / Km Adjuster */}
          <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-xs">
            <span className="text-[11px] text-neutral-400 font-medium">Distância Estimada:</span>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min="1"
                max="35"
                step="0.5"
                value={distanciaKm}
                onChange={(e) => setDistanciaKm(parseFloat(e.target.value))}
                className="w-24 accent-[#a3e635] cursor-pointer"
              />
              <span className="font-extrabold text-[#a3e635] min-w-[50px] text-right">
                {distanciaKm.toFixed(1)} km
              </span>
            </div>
          </div>
        </div>

        {/* QUICK PRESET CHIPS IN JOÃO PESSOA */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar text-[11px]">
          {JOAO_PESSOA_LOCATIONS.slice(0, 5).map((loc) => (
            <button
              key={loc.name}
              onClick={() => setDestino(loc.name)}
              className="px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 whitespace-nowrap shrink-0 transition-colors font-medium"
            >
              📍 {loc.bairro}
            </button>
          ))}
        </div>

        {/* INTERACTIVE MAP OF JOÃO PESSOA */}
        <InteractiveMap
          origem={origem}
          destino={destino}
          distanciaKm={distanciaKm}
          tempoMin={Math.max(5, Math.round(distanciaKm * 2.2))}
          valorEstimado={currentTotal}
        />

        {/* SURGE PRICING DYNAMIC TOGGLE */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-sky-950/20 border border-sky-500/30 text-xs">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-sky-400 shrink-0" />
            <div>
              <span className="font-bold text-white block">Tarifa Dinâmica (3.5x)</span>
              <span className="text-[10px] text-neutral-400">Trânsito intenso, chuva ou alta demanda</span>
            </div>
          </div>
          <button
            onClick={() => setSurgeActive(!surgeActive)}
            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all ${
              surgeActive
                ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_12px_rgba(163,230,53,0.4)]'
                : 'bg-neutral-800 text-neutral-300'
            }`}
          >
            {surgeActive ? 'Ativada' : 'Ativar'}
          </button>
        </div>

        {/* LUGARES SALVOS (Matching screenshot) */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
              Lugares salvos
            </h3>
            <button className="text-[11px] font-semibold text-[#a3e635] hover:underline">
              Ver todos
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1 cursor-pointer hover:border-neutral-700 transition-colors">
              <Home className="w-5 h-5 text-[#a3e635]" />
              <span className="text-xs font-bold text-white">Casa</span>
              <span className="text-[9px] text-neutral-400 leading-tight">Adicionar endereço</span>
            </div>

            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1 cursor-pointer hover:border-neutral-700 transition-colors">
              <Briefcase className="w-5 h-5 text-[#a3e635]" />
              <span className="text-xs font-bold text-white">Trabalho</span>
              <span className="text-[9px] text-neutral-400 leading-tight">Adicionar endereço</span>
            </div>

            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1 cursor-pointer hover:border-neutral-700 transition-colors">
              <Heart className="w-5 h-5 text-[#a3e635]" />
              <span className="text-xs font-bold text-white">Favoritos</span>
              <span className="text-[9px] text-neutral-400 leading-tight">Seus lugares salvos</span>
            </div>
          </div>
        </div>

        {/* ESCOLHA O SERVIÇO / CATEGORIES (Matching screenshot) */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
              Escolha o serviço
            </h3>
            <button
              onClick={() => setViewMode(viewMode === 'home' ? 'all_services' : 'home')}
              className="text-[11px] font-semibold text-[#a3e635] hover:underline"
            >
              {viewMode === 'home' ? 'Ver todos' : 'Visão Resumida'}
            </button>
          </div>

          {/* CATEGORY CARDS - GRID OR LIST ACCORDING TO VIEWMODE */}
          {viewMode === 'all_services' ? (
            <div className="space-y-2.5 animate-fadeIn">
              <p className="text-xs text-neutral-400">
                Confira todas as categorias e escolha a que melhor atende às suas necessidades.
              </p>

              <div className="space-y-2">
                {CATEGORIES.map((cat) => {
                  const isSelected = selectedCategory.id === cat.id;
                  const fare = calculateTotal(cat);

                  return (
                    <div
                      key={cat.id}
                      onClick={() => handleSelectCategory(cat)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isSelected
                          ? 'bg-neutral-900 border-[#a3e635] shadow-[0_0_18px_rgba(163,230,53,0.2)]'
                          : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-[#142607] border border-[#a3e635]/30 flex items-center justify-center shrink-0">
                          <VehicleGraphic type={cat.iconType} size="sm" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-black text-white">{cat.name}</span>
                            {cat.tag && (
                              <span className="px-1.5 py-0.5 rounded-full bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635] text-[8px] font-black">
                                {cat.tag}
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-neutral-400">
                            Fixo R$ {cat.baseFare.toFixed(2).replace('.', ',')} • Km adic. R$ {cat.kmAdicional.toFixed(2).replace('.', ',')}
                          </div>
                          <div className="text-[9px] text-neutral-500">
                            {cat.capacity}
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-[10px] text-neutral-400">Total Viagem</div>
                        <div className="text-sm font-black text-[#a3e635]">
                          R$ {fare.toFixed(2).replace('.', ',')}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* GRID OF CATEGORY CARDS (Home screen view matching screen 2) */
            <div className="grid grid-cols-2 sm:grid-cols-2 gap-2.5">
              {CATEGORIES.map((cat) => {
                const isSelected = selectedCategory.id === cat.id;
                const fare = calculateTotal(cat);

                return (
                  <div
                    key={cat.id}
                    onClick={() => handleSelectCategory(cat)}
                    className={`p-3 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between relative ${
                      isSelected
                        ? 'bg-neutral-900 border-[#a3e635] shadow-[0_0_18px_rgba(163,230,53,0.25)]'
                        : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    {cat.tag && (
                      <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded-full bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635] text-[9px] font-black">
                        {cat.tag}
                      </span>
                    )}

                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-extrabold text-white truncate max-w-[70%]">
                        {cat.name}
                      </span>
                    </div>

                    <div className="my-1 flex justify-center py-1">
                      <VehicleGraphic type={cat.iconType} size="md" />
                    </div>

                    <div className="mt-2 pt-2 border-t border-neutral-800/80">
                      <div className="text-[10px] text-neutral-400 leading-tight">
                        Fixo R$ {cat.baseFare.toFixed(2).replace('.', ',')}
                      </div>
                      <div className="text-[10px] text-neutral-400 leading-tight">
                        Km adic. R$ {cat.kmAdicional.toFixed(2).replace('.', ',')}
                      </div>

                      <div className="flex items-baseline justify-between mt-1.5">
                        <span className="text-[10px] text-neutral-400">Total:</span>
                        <strong className="text-sm font-black text-[#a3e635]">
                          R$ {fare.toFixed(2).replace('.', ',')}
                        </strong>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* INDIQUE E GANHE BANNER (From screenshot) */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#172b05] via-[#0d1a03] to-[#172b05] border border-[#a3e635]/30 flex items-center justify-between cursor-pointer hover:scale-[1.01] transition-transform">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-[#a3e635] text-neutral-950">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-black text-white">Indique e Ganhe R$ 10,00</div>
              <div className="text-[10px] text-neutral-300">
                Compartilhe seu código com amigos em João Pessoa
              </div>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-[#a3e635]" />
        </div>

        {/* CTA BUTTON TO PROCEED */}
        <button
          onClick={() => {
            if (!destino || destino.trim() === '') {
              alert('Por favor, informe o endereço de destino obrigatório.');
              return;
            }
            onProceedToPayment();
          }}
          className="w-full py-4 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] active:scale-[0.99] text-neutral-950 font-black text-sm tracking-tight transition-all shadow-[0_4px_20px_rgba(163,230,53,0.35)] flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>Confirmar {selectedCategory.name} • R$ {currentTotal.toFixed(2).replace('.', ',')}</span>
          <span>➔</span>
        </button>
      </div>

      {/* BOTTOM NAVIGATION BAR (Início, Explorar, Favoritos, Perfil) */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-[#0a0a0a]/95 border-t border-neutral-800/80 backdrop-blur-md grid grid-cols-4 items-center z-40">
        <button
          onClick={() => setActiveBottomNav('inicio')}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeBottomNav === 'inicio' ? 'text-[#a3e635]' : 'text-neutral-500'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-bold">Início</span>
        </button>

        <button
          onClick={() => setActiveBottomNav('explorar')}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeBottomNav === 'explorar' ? 'text-[#a3e635]' : 'text-neutral-500'
          }`}
        >
          <Compass className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Explorar</span>
        </button>

        <button
          onClick={() => setActiveBottomNav('favoritos')}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeBottomNav === 'favoritos' ? 'text-[#a3e635]' : 'text-neutral-500'
          }`}
        >
          <Heart className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Favoritos</span>
        </button>

        <button
          onClick={() => setActiveBottomNav('perfil')}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeBottomNav === 'perfil' ? 'text-[#a3e635]' : 'text-neutral-500'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Perfil</span>
        </button>
      </div>

      {/* W-SOS EMERGENCY MODAL */}
      <SosModal
        isOpen={showSosModal}
        onClose={() => setShowSosModal(false)}
        userRole="passageiro"
      />

      {/* TAXI DETAIL MODAL */}
      {showTaxiModal && (
        <TaxiDetailModal
          onClose={() => setShowTaxiModal(false)}
          onConfirm={() => {
            setShowTaxiModal(false);
            onProceedToPayment();
          }}
        />
      )}
    </div>
  );
};
