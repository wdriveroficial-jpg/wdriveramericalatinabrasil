import React from 'react';
import { Zap, Radio } from 'lucide-react';
import { WDriverLogo } from './WDriverLogo';

interface RadarMapProps {
  surgeActive: boolean;
  baseMotoPrice: number;
  baseCarPrice: number;
  multiplier?: number;
  selectedCategory: 'w_moto' | 'w_carro';
  onSelectCategory: (cat: 'w_moto' | 'w_carro') => void;
  onRequestClick: () => void;
  className?: string;
}

export const RadarMap: React.FC<RadarMapProps> = ({
  surgeActive,
  baseMotoPrice,
  baseCarPrice,
  multiplier = 3.5,
  selectedCategory,
  onSelectCategory,
  onRequestClick,
  className = '',
}) => {
  const motoTotal = surgeActive ? baseMotoPrice * multiplier : baseMotoPrice;
  const carroTotal = surgeActive ? baseCarPrice * multiplier : baseCarPrice;

  return (
    <div className={`relative w-full h-[520px] rounded-3xl overflow-hidden border border-neutral-800 bg-[#070b10] select-none shadow-2xl flex flex-col justify-between ${className}`}>
      {/* BACKGROUND RADAR GRID & TOPOLOGY */}
      <div className="absolute inset-0 pointer-events-none">
        <svg viewBox="0 0 400 520" className="w-full h-full object-cover">
          <defs>
            <radialGradient id="radarSweep" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.25" />
              <stop offset="70%" stopColor="#0284c7" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#0284c7" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="blueHeat1" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.75" />
              <stop offset="50%" stopColor="#0284c7" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#082f49" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="greenHeat" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#a3e635" stopOpacity="0.6" />
              <stop offset="60%" stopColor="#4d7c0f" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#1e3a05" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Dark map roads and geography */}
          <g stroke="#1e293b" strokeWidth="1.5" opacity="0.4">
            <path d="M 50 20 Q 150 180 200 480" fill="none" />
            <path d="M 280 10 Q 240 220 300 500" fill="none" />
            <path d="M 20 180 Q 200 150 380 120" fill="none" />
            <path d="M 10 320 Q 180 340 390 310" fill="none" />
            <path d="M 60 90 L 340 90" />
            <path d="M 40 250 L 360 250" />
            <path d="M 80 410 L 320 410" />
          </g>

          {/* Shoreline contour */}
          <path
            d="M 330 0 Q 300 140 310 260 T 340 520"
            fill="none"
            stroke="#0ea5e9"
            strokeWidth="3"
            opacity="0.3"
          />

          {/* Glowing Surge Heat Zones (Blue & Green blobs) */}
          <circle cx="210" cy="140" r="55" fill="url(#blueHeat1)" className="animate-pulse" />
          <circle cx="110" cy="210" r="50" fill="url(#blueHeat1)" />
          <circle cx="200" cy="270" r="70" fill="url(#greenHeat)" />
          <circle cx="160" cy="380" r="60" fill="url(#blueHeat1)" />

          {/* Concentric Radar Rings in Center */}
          <g transform="translate(240, 240)">
            <circle r="110" fill="none" stroke="#0284c7" strokeWidth="1" strokeDasharray="3 4" opacity="0.4" />
            <circle r="75" fill="none" stroke="#38bdf8" strokeWidth="1.5" opacity="0.6" />
            <circle r="45" fill="url(#radarSweep)" stroke="#38bdf8" strokeWidth="1.5" className="animate-pulse" />
            
            {/* Target Crosshair */}
            <line x1="-80" y1="0" x2="80" y2="0" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="2 3" opacity="0.3" />
            <line x1="0" y1="-80" x2="0" y2="80" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="2 3" opacity="0.3" />
            
            {/* Center Driver Dot */}
            <circle r="14" fill="#1a2e05" stroke="#a3e635" strokeWidth="3" />
            <circle r="6" fill="#a3e635" />
          </g>

          {/* Regional Labels */}
          <g fill="#475569" fontSize="11" fontWeight="800" letterSpacing="1">
            <text x="195" y="225">Centro</text>
            <text x="135" y="340">Zona Sul</text>
          </g>
        </svg>

        {/* SURGE BADGES (Floating directly on heat spots like in reference image) */}
        {/* +R$ 40 Badge North */}
        <div className="absolute top-[8%] right-[25%] z-10 animate-bounce" style={{ animationDuration: '3s' }}>
          <span className="px-2.5 py-1 rounded-full bg-[#a3e635] text-neutral-950 font-black text-xs shadow-[0_0_14px_rgba(163,230,53,0.7)] border border-white/40">
            +R$ 40
          </span>
        </div>

        {/* +R$ 30 Badge North-East */}
        <div className="absolute top-[18%] right-[32%] z-10">
          <span className="px-2.5 py-1 rounded-full bg-[#a3e635] text-neutral-950 font-black text-xs shadow-[0_0_14px_rgba(163,230,53,0.7)] border border-white/40">
            +R$ 30
          </span>
        </div>

        {/* +R$ 20 Badges */}
        <div className="absolute top-[28%] left-[46%] z-10">
          <span className="px-2.5 py-1 rounded-full bg-[#a3e635] text-neutral-950 font-black text-xs shadow-[0_0_14px_rgba(163,230,53,0.7)] border border-white/40">
            +R$ 20
          </span>
        </div>
        <div className="absolute top-[35%] left-[44%] z-10">
          <span className="px-2.5 py-1 rounded-full bg-[#a3e635] text-neutral-950 font-black text-xs shadow-[0_0_14px_rgba(163,230,53,0.7)] border border-white/40">
            +R$ 20
          </span>
        </div>

        {/* +R$ 15 Badge West */}
        <div className="absolute top-[42%] left-[10%] z-10">
          <span className="px-2.5 py-1 rounded-full bg-[#a3e635] text-neutral-950 font-black text-xs shadow-[0_0_14px_rgba(163,230,53,0.7)] border border-white/40">
            +R$ 15
          </span>
        </div>

        {/* Central Multiplier (3,5x) on Driver */}
        <div className="absolute top-[41%] right-[34%] z-20">
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#a3e635] text-neutral-950 font-black text-xs shadow-[0_0_18px_rgba(163,230,53,0.9)] border-2 border-neutral-950 scale-105">
            <Zap className="w-3 h-3 fill-neutral-950" />
            <span>{multiplier.toFixed(1).replace('.', ',')}x</span>
          </div>
        </div>

        {/* +R$ 30 Badges South */}
        <div className="absolute bottom-[36%] right-[32%] z-10">
          <span className="px-2.5 py-1 rounded-full bg-[#a3e635] text-neutral-950 font-black text-xs shadow-[0_0_14px_rgba(163,230,53,0.7)] border border-white/40">
            +R$ 30
          </span>
        </div>
        <div className="absolute bottom-[28%] left-[28%] z-10">
          <span className="px-2.5 py-1 rounded-full bg-[#a3e635] text-neutral-950 font-black text-xs shadow-[0_0_14px_rgba(163,230,53,0.7)] border border-white/40">
            +R$ 30
          </span>
        </div>
      </div>

      {/* TOP HEADER: Branding & Live Radar Status */}
      <div className="relative z-20 flex items-center justify-between p-4 bg-gradient-to-b from-[#0a0a0a]/90 via-[#0a0a0a]/60 to-transparent">
        <WDriverLogo size="sm" />
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 text-[11px] font-bold">
            <Radio className="w-3 h-3 animate-spin" />
            <span>Radar Ao Vivo</span>
          </div>
        </div>
      </div>

      {/* BOTTOM CONTROLS & SELECTION CARDS (Matching user's screenshot exactly) */}
      <div className="relative z-20 p-4 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/95 to-transparent flex flex-col gap-3">
        {/* Category Toggles */}
        <div className="grid grid-cols-2 gap-2.5">
          {/* W-MOTO Card */}
          <button
            onClick={() => onSelectCategory('w_moto')}
            className={`flex items-center gap-2.5 p-3 rounded-2xl border transition-all text-left ${
              selectedCategory === 'w_moto'
                ? 'bg-neutral-900 border-[#a3e635] shadow-[0_0_16px_rgba(163,230,53,0.25)]'
                : 'bg-neutral-950/80 border-neutral-800 opacity-75 hover:opacity-100'
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center font-black text-[#a3e635] text-sm shrink-0">
              W
            </div>
            <div className="truncate">
              <div className={`text-xs font-black ${selectedCategory === 'w_moto' ? 'text-white' : 'text-neutral-400'}`}>
                W-MOTO
              </div>
              <div className="text-xs font-extrabold text-[#a3e635]">
                R$ {motoTotal.toFixed(2).replace('.', ',')} {surgeActive ? `- ${multiplier.toFixed(1).replace('.', ',')}x` : ''}
              </div>
            </div>
          </button>

          {/* W-CARRO Card */}
          <button
            onClick={() => onSelectCategory('w_carro')}
            className={`flex items-center gap-2.5 p-3 rounded-2xl border transition-all text-left ${
              selectedCategory === 'w_carro'
                ? 'bg-neutral-900 border-[#a3e635] shadow-[0_0_16px_rgba(163,230,53,0.25)]'
                : 'bg-neutral-950/80 border-neutral-800 opacity-75 hover:opacity-100'
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-neutral-900 border border-neutral-700 flex items-center justify-center text-neutral-400 text-sm shrink-0">
              🚗
            </div>
            <div className="truncate">
              <div className={`text-xs font-black ${selectedCategory === 'w_carro' ? 'text-white' : 'text-neutral-400'}`}>
                W-CARRO
              </div>
              <div className="text-xs font-extrabold text-[#a3e635]">
                R$ {carroTotal.toFixed(2).replace('.', ',')} {surgeActive ? `- ${multiplier.toFixed(1).replace('.', ',')}x` : ''}
              </div>
            </div>
          </button>
        </div>

        {/* Big Action Button */}
        <button
          onClick={onRequestClick}
          className="w-full py-4 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] active:scale-[0.99] text-neutral-950 font-black text-sm tracking-tight transition-all shadow-[0_4px_20px_rgba(163,230,53,0.35)] flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>
            Solicitar {selectedCategory === 'w_moto' ? 'W-MOTO' : 'W-CARRO'} {surgeActive ? '(Dinâmica Ativa)' : ''}
          </span>
          <span className="text-lg">➔</span>
        </button>
      </div>
    </div>
  );
};
