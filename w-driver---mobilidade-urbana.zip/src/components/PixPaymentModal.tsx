import React, { useState, useEffect } from 'react';
import { QrCode, Copy, CheckCircle2, ArrowLeft, Clock, ShieldCheck, Sparkles, Building2 } from 'lucide-react';
import { RideData } from '../types';

interface PixPaymentModalProps {
  ride: RideData;
  onPaymentSuccess: () => void;
  onBack: () => void;
}

export const PixPaymentModal: React.FC<PixPaymentModalProps> = ({
  ride,
  onPaymentSuccess,
  onBack,
}) => {
  const [copied, setCopied] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(900); // 15 mins
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(ride.codigoPix);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleSimulatePayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onPaymentSuccess();
    }, 800);
  };

  return (
    <div className="w-full max-w-md mx-auto bg-[#0d120d] border border-neutral-800 rounded-3xl p-5 shadow-2xl flex flex-col space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-800/80 pb-3">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar</span>
        </button>
        <div className="flex items-center gap-1 text-xs font-bold text-emerald-400">
          <ShieldCheck className="w-4 h-4" />
          <span>PIX Banco Central</span>
        </div>
      </div>

      {/* Ride Summary Pill */}
      <div className="p-3 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-xs">
        <div className="flex justify-between items-center text-neutral-400 mb-1">
          <span>{ride.categoria.name}</span>
          <span>{ride.distanciaKm.toFixed(1)} km • {ride.tempoEstimadoMin} min</span>
        </div>
        <div className="text-neutral-200 font-semibold truncate">
          {ride.origem.split(',')[0]} ➔ {ride.destino.split(',')[0]}
        </div>
      </div>

      {/* Amount Display */}
      <div className="text-center py-2 bg-gradient-to-b from-[#142308] to-transparent rounded-2xl border border-[#a3e635]/20">
        <div className="text-xs text-neutral-400 font-medium">Valor total a pagar</div>
        <div className="text-3xl font-black text-[#a3e635] tracking-tight">
          R$ {ride.valorTotal.toFixed(2).replace('.', ',')}
        </div>
        <div className="flex items-center justify-center gap-2 mt-1 text-[11px] text-neutral-400">
          <Clock className="w-3.5 h-3.5 text-amber-400" />
          <span>QR Code expira em: <strong className="text-white">{formatTimer(secondsLeft)}</strong></span>
        </div>
      </div>

      {/* QR Code Container */}
      <div className="flex flex-col items-center justify-center p-4 bg-white rounded-2xl shadow-inner mx-auto">
        <div className="relative p-2 border-2 border-neutral-900 rounded-xl bg-white">
          <svg viewBox="0 0 140 140" className="w-40 h-40">
            {/* Corner position markers */}
            <rect x="10" y="10" width="35" height="35" fill="#000" rx="4" />
            <rect x="17" y="17" width="21" height="21" fill="#fff" rx="2" />
            <rect x="23" y="23" width="9" height="9" fill="#000" />

            <rect x="95" y="10" width="35" height="35" fill="#000" rx="4" />
            <rect x="102" y="17" width="21" height="21" fill="#fff" rx="2" />
            <rect x="108" y="23" width="9" height="9" fill="#000" />

            <rect x="10" y="95" width="35" height="35" fill="#000" rx="4" />
            <rect x="17" y="102" width="21" height="21" fill="#fff" rx="2" />
            <rect x="23" y="108" width="9" height="9" fill="#000" />

            {/* Matrix dots simulating real PIX payload */}
            <g fill="#111">
              <circle cx="55" cy="20" r="3" />
              <circle cx="68" cy="22" r="3" />
              <circle cx="80" cy="18" r="3" />
              <circle cx="55" cy="35" r="3" />
              <circle cx="70" cy="38" r="3" />
              <circle cx="85" cy="32" r="3" />

              <circle cx="20" cy="55" r="3" />
              <circle cx="35" cy="60" r="3" />
              <circle cx="25" cy="75" r="3" />
              <circle cx="40" cy="80" r="3" />

              <circle cx="55" cy="55" r="3" />
              <circle cx="65" cy="65" r="3" />
              <circle cx="78" cy="55" r="3" />
              <circle cx="88" cy="65" r="3" />
              <circle cx="55" cy="78" r="3" />
              <circle cx="70" cy="85" r="3" />
              <circle cx="85" cy="78" r="3" />

              <circle cx="105" cy="55" r="3" />
              <circle cx="120" cy="62" r="3" />
              <circle cx="110" cy="75" r="3" />
              <circle cx="125" cy="85" r="3" />

              <circle cx="55" cy="105" r="3" />
              <circle cx="70" cy="115" r="3" />
              <circle cx="85" cy="108" r="3" />
              <circle cx="60" cy="125" r="3" />
              <circle cx="75" cy="128" r="3" />
              <circle cx="90" cy="122" r="3" />

              <circle cx="105" cy="105" r="3" />
              <circle cx="120" cy="115" r="3" />
              <circle cx="112" cy="125" r="3" />
            </g>

            {/* Centered W logo inside QR */}
            <rect x="58" y="58" width="24" height="24" rx="6" fill="#1a2e05" stroke="#a3e635" strokeWidth="1.5" />
            <text x="70" y="74" fontSize="13" fontWeight="900" fill="#a3e635" textAnchor="middle" fontFamily="sans-serif">W</text>
          </svg>
        </div>
        <span className="text-[11px] text-neutral-600 font-bold mt-2">
          Abra o app do seu banco e escaneie o QR Code
        </span>
      </div>

      {/* Copy-Paste PIX Section */}
      <div className="space-y-1.5">
        <label className="text-xs font-semibold text-neutral-400 block">
          Código PIX Copia e Cola:
        </label>
        <div className="flex items-center gap-2 bg-neutral-950 border border-neutral-800 rounded-xl p-2">
          <input
            type="text"
            readOnly
            value={ride.codigoPix}
            className="bg-transparent text-xs text-emerald-300 font-mono flex-1 outline-none truncate"
          />
          <button
            onClick={handleCopy}
            className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1 shrink-0 transition-colors"
          >
            {copied ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-[#a3e635]" />
                <span className="text-[#a3e635]">Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copiar</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Repasse Division Info (90% / 10%) */}
      <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/20 text-xs flex items-center justify-between text-neutral-300">
        <div className="flex items-center gap-2">
          <Building2 className="w-4 h-4 text-emerald-400" />
          <span>Repasse Motorista (90%):</span>
        </div>
        <strong className="text-emerald-300 font-bold">
          R$ {ride.repasseMotorista.toFixed(2).replace('.', ',')}
        </strong>
      </div>

      {/* Simulation Button */}
      <button
        onClick={handleSimulatePayment}
        disabled={isProcessing}
        className="w-full py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-sm transition-all shadow-[0_4px_16px_rgba(163,230,53,0.3)] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
      >
        {isProcessing ? (
          <span className="flex items-center gap-2">
            <span className="w-4 h-4 rounded-full border-2 border-neutral-950 border-t-transparent animate-spin" />
            Processando PIX no Banco Central...
          </span>
        ) : (
          <>
            <Sparkles className="w-4 h-4" />
            <span>Simular Pagamento Confirmado (Central 24h)</span>
          </>
        )}
      </button>
    </div>
  );
};
