import React from 'react';

interface WDriverLogoProps {
  variant?: 'full' | 'icon' | 'wbank' | 'splash';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const WDriverLogo: React.FC<WDriverLogoProps> = ({
  variant = 'full',
  size = 'md',
  className = '',
}) => {
  const sizeMap = {
    sm: { icon: 28, text: 'text-base', sub: 'text-[9px]' },
    md: { icon: 38, text: 'text-xl', sub: 'text-[11px]' },
    lg: { icon: 54, text: 'text-3xl', sub: 'text-xs' },
    xl: { icon: 84, text: 'text-5xl', sub: 'text-sm' },
  };

  const { icon: iconSize, text: textSize, sub: subSize } = sizeMap[size];

  // SVG representation of the stylized 'W' with an asphalt highway curve and white dashes
  const LogoIcon = (
    <div 
      className="relative flex items-center justify-center shrink-0 rounded-2xl overflow-hidden shadow-lg transition-transform hover:scale-105"
      style={{
        width: `${iconSize}px`,
        height: `${iconSize}px`,
        background: 'radial-gradient(circle at 30% 20%, #1e3a05 0%, #0d1705 70%, #050a02 100%)',
        border: '1.5px solid rgba(163, 230, 53, 0.4)',
        boxShadow: '0 4px 16px rgba(163, 230, 53, 0.25), inset 0 1px 2px rgba(255, 255, 255, 0.2)'
      }}
    >
      <svg
        viewBox="0 0 100 100"
        className="w-[82%] h-[82%] drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="wLimeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#bef264" />
            <stop offset="50%" stopColor="#a3e635" />
            <stop offset="100%" stopColor="#65a30d" />
          </linearGradient>
          <linearGradient id="roadGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1e293b" />
            <stop offset="50%" stopColor="#0f172a" />
            <stop offset="100%" stopColor="#020617" />
          </linearGradient>
          <filter id="glowLime" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="0" stdDeviation="3" floodColor="#a3e635" floodOpacity="0.6"/>
          </filter>
        </defs>

        {/* Left Arm of W */}
        <path
          d="M 16 22 L 32 82 L 44 82 L 34 22 Z"
          fill="url(#wLimeGrad)"
          className="filter drop-shadow"
        />

        {/* Right Arm of W */}
        <path
          d="M 66 22 L 56 82 L 68 82 L 84 22 Z"
          fill="url(#wLimeGrad)"
        />

        {/* Central Road Diagonal Ribbon that arches dynamically */}
        <path
          d="M 28 80 Q 48 38 82 24 L 72 20 Q 40 34 20 76 Z"
          fill="url(#roadGrad)"
          stroke="#a3e635"
          strokeWidth="1.2"
        />

        {/* White dashed highway centerline */}
        <path
          d="M 24 78 Q 45 36 78 22"
          stroke="#ffffff"
          strokeWidth="2.8"
          strokeDasharray="4 4"
          strokeLinecap="round"
        />

        {/* Center Peak Lime highlight */}
        <path
          d="M 44 82 L 52 46 L 58 46 L 56 82 Z"
          fill="url(#wLimeGrad)"
        />
      </svg>
    </div>
  );

  if (variant === 'icon') {
    return <div className={`inline-flex items-center ${className}`}>{LogoIcon}</div>;
  }

  if (variant === 'wbank') {
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        {LogoIcon}
        <div className="flex flex-col leading-none">
          <div className="flex items-center font-extrabold tracking-tight">
            <span className="text-[#a3e635] text-2xl font-black">W-</span>
            <span className="text-white text-2xl font-black tracking-wider">BANK</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-medium tracking-wide mt-0.5">
            Conta & Carteira Digital do Motorista
          </span>
        </div>
      </div>
    );
  }

  if (variant === 'splash') {
    return (
      <div className={`flex flex-col items-center text-center ${className}`}>
        <div className="mb-4 transform hover:scale-105 transition-transform duration-300">
          {LogoIcon}
        </div>
        <div className="flex items-center justify-center font-extrabold tracking-tight leading-none">
          <span className="text-[#a3e635] text-4xl font-black tracking-tight">W-</span>
          <span className="text-white text-4xl font-black tracking-wide">DRIVER</span>
        </div>
        <p className="text-xs uppercase tracking-[0.2em] font-semibold text-neutral-300 mt-2">
          Transporte legal de passageiros
        </p>
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {LogoIcon}
      <div className="flex flex-col leading-tight select-none">
        <div className={`font-black tracking-tight flex items-baseline ${textSize}`}>
          <span className="text-[#a3e635]">W-</span>
          <span className="text-white font-extrabold">DRIVER</span>
        </div>
        <span className={`text-neutral-400 font-medium tracking-normal ${subSize}`}>
          Transporte legal de passageiros
        </span>
      </div>
    </div>
  );
};
