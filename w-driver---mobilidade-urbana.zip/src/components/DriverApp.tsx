import React, { useState, useEffect } from 'react';
import { RadarMap } from './RadarMap';
import { RideData } from '../types';
import { Navigation, Compass, MapPin, CheckCircle2, XCircle, ExternalLink, Zap, ShieldCheck, Wallet, Clock, Video, AlertTriangle } from 'lucide-react';
import { SosModal } from './SosModal';
import { NoShowVideoModal } from './NoShowVideoModal';

interface DriverAppProps {
  activeRide: RideData | null;
  surgeActive: boolean;
  onToggleSurge: () => void;
  onAcceptRide: (rideId: string) => void;
  onUpdateRideStatus: (rideId: string, status: RideData['status']) => void;
  onOpenWBank: () => void;
}

export const DriverApp: React.FC<DriverAppProps> = ({
  activeRide,
  surgeActive,
  onToggleSurge,
  onAcceptRide,
  onUpdateRideStatus,
  onOpenWBank,
}) => {
  const [selectedCat, setSelectedCat] = useState<'w_moto' | 'w_carro'>('w_moto');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [showSosModal, setShowSosModal] = useState(false);
  const [showNoShowModal, setShowNoShowModal] = useState(false);
  const [secondsWaiting, setSecondsWaiting] = useState(180); // 3 minutes = 180s
  const [timerRunning, setTimerRunning] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (activeRide?.status === 'motorista_no_local' && timerRunning && secondsWaiting > 0) {
      interval = setInterval(() => {
        setSecondsWaiting((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [activeRide?.status, timerRunning, secondsWaiting]);

  // When driver arrives at location, auto start 3 min timer
  useEffect(() => {
    if (activeRide?.status === 'motorista_no_local') {
      setTimerRunning(true);
      setSecondsWaiting(180);
    } else {
      setTimerRunning(false);
    }
  }, [activeRide?.status]);

  const formatTimer = (totalSec: number) => {
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const handleOpenGps = (app: 'Google Maps' | 'Waze' | 'Navegador') => {
    if (!activeRide) return;
    const dest = encodeURIComponent(activeRide.origem);
    let url = `https://www.google.com/maps/search/?api=1&query=${dest}`;
    if (app === 'Waze') {
      url = `https://waze.com/ul?q=${dest}`;
    }
    window.open(url, '_blank');
  };

  const handleFinishRide = () => {
    if (!activeRide) return;
    onUpdateRideStatus(activeRide.id, 'concluida');
    setStatusMessage('✅ Viagem finalizada com sucesso! 90% creditados na sua conta W-BANK.');
  };

  const handleCancelRide = () => {
    if (!activeRide) return;
    onUpdateRideStatus(activeRide.id, 'cancelada');
    setStatusMessage('❌ Corrida cancelada antes do embarque. Nenhum valor cobrado ou creditado.');
  };

  const handleConfirmNoShow = () => {
    if (!activeRide) return;
    onUpdateRideStatus(activeRide.id, 'cancelada');
    setStatusMessage('🚨 Evidência 360° enviada! Passageiro ausente comprovado. Taxa de No-Show creditada no W-BANK.');
  };

  return (
    <div className="w-full space-y-4">
      {/* Driver Header & Quick Status */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-center text-xl">
            🏍️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-white text-sm">Carlos Motorista VIP</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                Status: Online Protegido (🟢)
              </span>
            </div>
            <p className="text-[11px] text-neutral-400">
              Honda CB 500F • Placa QFA-9921 • Nota 4.98 ⭐
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Driver W-SOS Button */}
          <button
            onClick={() => setShowSosModal(true)}
            className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-black flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>W-SOS</span>
          </button>

          {/* Surge Toggle */}
          <button
            onClick={onToggleSurge}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              surgeActive
                ? 'bg-[#1a2e05] border-[#a3e635] text-[#a3e635] shadow-[0_0_12px_rgba(163,230,53,0.3)]'
                : 'bg-neutral-950 border-neutral-800 text-neutral-400'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${surgeActive ? 'fill-[#a3e635]' : ''}`} />
            <span>{surgeActive ? 'Dinâmica 3.5x' : 'Ativar Dinâmica'}</span>
          </button>

          {/* W-Bank Button */}
          <button
            onClick={onOpenWBank}
            className="px-3 py-1.5 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Wallet className="w-3.5 h-3.5 text-emerald-400" />
            <span>W-BANK</span>
          </button>
        </div>
      </div>

      {/* ACTIVE DISPATCHED RIDE CARD */}
      {activeRide && (
        <div className="p-5 rounded-3xl bg-neutral-900 border-2 border-[#a3e635] shadow-[0_0_24px_rgba(163,230,53,0.15)] space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div className="flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#a3e635] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-[#a3e635]"></span>
              </span>
              <span className="text-xs font-black text-white uppercase tracking-wider">
                {activeRide.status === 'despachada'
                  ? '🚨 Nova Corrida Liberada pela Central!'
                  : `Viagem em Curso (${activeRide.status.replace(/_/g, ' ')})`}
              </span>
            </div>
            <span className="px-2.5 py-0.5 rounded-full bg-neutral-800 text-[11px] font-bold text-neutral-300">
              {activeRide.categoria.name}
            </span>
          </div>

          {/* Locations */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800">
              <span className="text-neutral-500 text-[10px] block font-medium">Buscar em (Origem)</span>
              <span className="text-white font-bold">{activeRide.origem}</span>
            </div>
            <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800">
              <span className="text-neutral-500 text-[10px] block font-medium">Levar até (Destino)</span>
              <span className="text-white font-bold">{activeRide.destino}</span>
            </div>
          </div>

          {/* Payout & Distance */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
            <div>
              <div className="text-[10px] text-emerald-400 font-medium">Seu Ganho Líquido (90% via W-BANK)</div>
              <div className="text-2xl font-black text-[#a3e635]">
                R$ {activeRide.repasseMotorista.toFixed(2).replace('.', ',')}
              </div>
            </div>
            <div className="text-right text-xs">
              <div className="text-neutral-400 font-medium">Distância Total</div>
              <div className="text-sm font-bold text-white">
                {activeRide.distanciaKm.toFixed(1)} km (~{activeRide.tempoEstimadoMin} min)
              </div>
            </div>
          </div>

          {/* GPS NAVIGATION SELECTORS */}
          <div className="space-y-1.5">
            <span className="text-[11px] text-neutral-400 font-semibold block">
              Abrir Navegador GPS até o Passageiro:
            </span>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => handleOpenGps('Google Maps')}
                className="py-2 px-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-xs font-bold text-neutral-200 flex items-center justify-center gap-1.5 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5 text-blue-400" />
                <span>Google Maps</span>
              </button>
              <button
                onClick={() => handleOpenGps('Waze')}
                className="py-2 px-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-xs font-bold text-neutral-200 flex items-center justify-center gap-1.5 transition-colors"
              >
                <Navigation className="w-3.5 h-3.5 text-cyan-400" />
                <span>Waze</span>
              </button>
              <button
                onClick={() => handleOpenGps('Navegador')}
                className="py-2 px-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-xs font-bold text-neutral-200 flex items-center justify-center gap-1.5 transition-colors"
              >
                <Compass className="w-3.5 h-3.5 text-emerald-400" />
                <span>Outro GPS</span>
              </button>
            </div>
          </div>

          {/* TRIP WORKFLOW ACTIONS */}
          <div className="pt-2 flex flex-col gap-2">
            {activeRide.status === 'despachada' && (
              <button
                onClick={() => onAcceptRide(activeRide.id)}
                className="w-full py-3 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-md"
              >
                Aceitar Corrida & Iniciar Deslocamento
              </button>
            )}

            {activeRide.status === 'motorista_a_caminho' && (
              <button
                onClick={() => onUpdateRideStatus(activeRide.id, 'motorista_no_local')}
                className="w-full py-3 rounded-2xl bg-sky-500 hover:bg-sky-400 text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-md"
              >
                📍 Cheguei ao Local de Embarque
              </button>
            )}

            {activeRide.status === 'motorista_no_local' && (
              <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-neutral-400 font-bold flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-[#a3e635]" />
                    Tempo Limite de Espera:
                  </span>
                  <span className={`font-mono text-sm font-black ${secondsWaiting <= 30 ? 'text-red-400 animate-pulse' : 'text-[#a3e635]'}`}>
                    {formatTimer(secondsWaiting)}
                  </span>
                </div>

                <div className="w-full bg-neutral-900 rounded-full h-2 overflow-hidden border border-neutral-800">
                  <div
                    className={`h-full transition-all duration-1000 ${
                      secondsWaiting <= 30 ? 'bg-red-500' : 'bg-[#a3e635]'
                    }`}
                    style={{ width: `${(secondsWaiting / 180) * 100}%` }}
                  />
                </div>

                <button
                  onClick={() => onUpdateRideStatus(activeRide.id, 'em_viagem')}
                  className="w-full py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer"
                >
                  🚀 Iniciar Corrida (Passageiro a Bordo)
                </button>

                <button
                  onClick={() => setShowNoShowModal(true)}
                  className="w-full py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-amber-300 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Video className="w-4 h-4" />
                  <span>🚨 Passageiro Ausente — Gravar Vídeo 360°</span>
                </button>
              </div>
            )}

            {activeRide.status === 'em_viagem' && (
              <button
                onClick={handleFinishRide}
                className="w-full py-3 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-md"
              >
                🏁 Chegamos ao Destino (Concluir Viagem)
              </button>
            )}

            {/* Cancel option before boarding */}
            {['despachada', 'motorista_a_caminho', 'motorista_no_local'].includes(activeRide.status) && (
              <button
                onClick={handleCancelRide}
                className="w-full py-2.5 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/40 text-red-300 font-bold text-xs transition-colors"
              >
                Cancelar Corrida (Antes do Embarque)
              </button>
            )}
          </div>
        </div>
      )}

      {/* FEEDBACK BANNER */}
      {statusMessage && (
        <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-xs text-neutral-200 text-center font-medium">
          {statusMessage}
        </div>
      )}

      {/* RADAR HEATMAP SCREEN (Exact matching file_000000002c1c820e91691086b4e83b08.png) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
          <span className="font-bold text-neutral-200">Radar Dinâmico de Demanda & Chuva</span>
          <span>Atualizado em tempo real</span>
        </div>

        <RadarMap
          surgeActive={surgeActive}
          baseMotoPrice={6.0}
          baseCarPrice={8.0}
          multiplier={3.5}
          selectedCategory={selectedCat}
          onSelectCategory={setSelectedCat}
          onRequestClick={() => {
            alert(`Categoria ${selectedCat.toUpperCase()} selecionada no Radar.`);
          }}
        />
      </div>

      {/* SOS EMERGENCY MODAL */}
      <SosModal
        isOpen={showSosModal}
        onClose={() => setShowSosModal(false)}
        userRole="motorista"
      />

      {/* 360 NO-SHOW VIDEO MODAL */}
      <NoShowVideoModal
        isOpen={showNoShowModal}
        onClose={() => setShowNoShowModal(false)}
        onConfirmNoShow={handleConfirmNoShow}
      />
    </div>
  );
};
