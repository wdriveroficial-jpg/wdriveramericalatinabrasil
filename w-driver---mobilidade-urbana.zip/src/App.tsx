import React, { useState } from 'react';
import { 
  Smartphone, CreditCard, Building2, Radio, Wallet, 
  ShieldCheck, HelpCircle, Check, Sparkles, Navigation2, Lock, Bell
} from 'lucide-react';
import { ActiveTab, CategoryInfo, RideData, RideStatus, UserRegistration } from './types';
import { CATEGORIES } from './data/categories';
import { WDriverLogo } from './components/WDriverLogo';
import { PassengerApp } from './components/PassengerApp';
import { PixPaymentModal } from './components/PixPaymentModal';
import { CentralControl } from './components/CentralControl';
import { DriverApp } from './components/DriverApp';
import { WBankDrawer } from './components/WBankDrawer';
import { DeviceFrame } from './components/DeviceFrame';
import { SecurityRegistration } from './components/SecurityRegistration';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('passageiro');
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(true);
  const [showWBankModal, setShowWBankModal] = useState<boolean>(false);
  const [surgeMultiplier, setSurgeMultiplier] = useState<number>(1.0);

  // User Security Registration State
  const [registration, setRegistration] = useState<UserRegistration>({
    nome: 'Carlos Roberto Lima',
    cpf: '042.881.992-01',
    telefone: '(83) 99812-4411',
    naturalidade: 'João Pessoa / PB',
    selfieEnviada: true,
    documentoEnviado: true,
    antecedentesEnviados: true,
    govBrAssinado: true,
    termosAceitos: true,
    status: 'aprovado',
  });

  const handleUpdateRegistration = (data: Partial<UserRegistration>) => {
    setRegistration((prev) => ({ ...prev, ...data }));
  };

  // Core Passenger inputs
  const [origem, setOrigem] = useState('Busto de Tamandaré, Cabo Branco');
  const [destino, setDestino] = useState('Manaíra Shopping, Zona Leste');
  const [distanciaKm, setDistanciaKm] = useState(8.3);
  const [selectedCategory, setSelectedCategory] = useState<CategoryInfo>(CATEGORIES[1]); // W-MOTO Comum
  const [surgeActive, setSurgeActive] = useState<boolean>(false);

  // Active Ride state
  const [currentRide, setCurrentRide] = useState<RideData | null>(null);

  // Historical rides for Central and W-BANK
  const [allRides, setAllRides] = useState<RideData[]>([
    {
      id: 'wd-8391',
      origem: 'Av. Cabo Branco, 1500',
      origemBairro: 'Cabo Branco',
      destino: 'Praça da Paz, Bancários',
      destinoBairro: 'Bancários',
      distanciaKm: 6.8,
      tempoEstimadoMin: 14,
      categoria: CATEGORIES[3], // W-CARRO Comum
      valorBase: 8.0,
      dinamicaAtiva: false,
      multiplicadorDinamica: 1.0,
      valorTotal: 12.9,
      repasseMotorista: 11.61,
      taxaPlataforma: 1.29,
      status: 'concluida',
      criadoEm: '10:40',
      chavePix: 'financeiro@wdriver.com.br',
      codigoPix: '00020126580014br.gov.bcb.pix0136wdriver-jp-8391',
      passageiroNome: 'Mariana Costa',
      motoristaNome: 'Carlos E. da Silva',
      motoristaVeiculo: 'Honda CB 500F',
      motoristaPlaca: 'QFA-9921',
    },
  ]);

  // Calculate fare helper
  const calculateTotalFare = (cat: CategoryInfo, km: number, surge: boolean) => {
    let fare = cat.baseFare;
    if (km > 4) {
      fare += (km - 4) * cat.kmAdicional;
    }
    if (surge) {
      fare *= 3.5;
    }
    return Math.round(fare * 100) / 100;
  };

  // Create new ride and move to payment
  const handleProceedToPayment = () => {
    const total = calculateTotalFare(selectedCategory, distanciaKm, surgeActive);
    const repasse = Math.round(total * 0.9 * 100) / 100;
    const taxa = Math.round((total - repasse) * 100) / 100;

    const newRide: RideData = {
      id: `wd-${Math.floor(1000 + Math.random() * 9000)}`,
      origem,
      origemBairro: origem.split(',')[1]?.trim() || 'João Pessoa',
      destino,
      destinoBairro: destino.split(',')[1]?.trim() || 'João Pessoa',
      distanciaKm,
      tempoEstimadoMin: Math.max(5, Math.round(distanciaKm * 2.2)),
      categoria: selectedCategory,
      valorBase: selectedCategory.baseFare,
      dinamicaAtiva: surgeActive,
      multiplicadorDinamica: surgeActive ? 3.5 : 1.0,
      valorTotal: total,
      repasseMotorista: repasse,
      taxaPlataforma: taxa,
      status: 'aguardando_pix',
      criadoEm: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      chavePix: 'wdriver.jp@pagamentos.com.br',
      codigoPix: `00020126580014br.gov.bcb.pix0136wdriver.jp.${Math.round(total * 100)}`,
      passageiroNome: 'Você (Passageiro)',
      motoristaNome: 'Carlos E. da Silva',
      motoristaVeiculo: 'Honda CB 500F',
      motoristaPlaca: 'QFA-9921',
    };

    setCurrentRide(newRide);
    setAllRides((prev) => [newRide, ...prev]);
    setActiveTab('pagamento');
  };

  // Simulate PIX confirmation from bank to Central
  const handlePaymentSuccess = () => {
    if (!currentRide) return;
    const updated: RideData = {
      ...currentRide,
      status: 'paga_central',
    };
    setCurrentRide(updated);
    setAllRides((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
    setActiveTab('central');
  };

  // Central authorizes and dispatches to Driver
  const handleApproveAndDispatch = (rideId: string) => {
    setAllRides((prev) =>
      prev.map((r) => {
        if (r.id === rideId) {
          const dispatched: RideData = { ...r, status: 'despachada' };
          if (currentRide?.id === rideId) {
            setCurrentRide(dispatched);
          }
          return dispatched;
        }
        return r;
      })
    );
    setActiveTab('motorista');
  };

  // Driver accepts ride
  const handleAcceptRide = (rideId: string) => {
    const updatedStatus: RideStatus = 'motorista_a_caminho';
    setAllRides((prev) =>
      prev.map((r) => (r.id === rideId ? { ...r, status: updatedStatus } : r))
    );
    if (currentRide?.id === rideId) {
      setCurrentRide((prev) => (prev ? { ...prev, status: updatedStatus } : null));
    }
  };

  // Update status along driver workflow
  const handleUpdateRideStatus = (rideId: string, status: RideStatus) => {
    setAllRides((prev) =>
      prev.map((r) => (r.id === rideId ? { ...r, status } : r))
    );
    if (currentRide?.id === rideId) {
      setCurrentRide((prev) => (prev ? { ...prev, status } : null));
    }
  };

  const completedRides = allRides.filter((r) => r.status === 'concluida');

  return (
    <div className="min-h-screen bg-[#070908] text-neutral-100 flex flex-col selection:bg-[#a3e635] selection:text-black">
      {/* MAIN TOPBAR */}
      <header className="sticky top-0 z-40 bg-[#0a0e0a]/95 backdrop-blur-md border-b border-neutral-800/80 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <WDriverLogo size="md" />
          <div className="hidden sm:block border-l border-neutral-800 pl-3">
            <span className="text-[10px] uppercase font-extrabold tracking-wider text-[#b2ec5d] block">
              AMÉRICA LATINA BRASIL
            </span>
            <span className="text-xs text-neutral-400 font-semibold block">
              Sistema Blindado Anti-Fraude e Anti-Calote
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-neutral-900 border border-neutral-800 text-xs">
            <span className="w-2 h-2 rounded-full bg-[#a3e635] animate-ping" />
            <span className="text-neutral-300 font-medium">João Pessoa - PB</span>
            <span className="text-neutral-500">•</span>
            <span className="text-[#a3e635] font-bold">Central 24h Ativa</span>
          </div>

          <button
            onClick={() => alert('Central W-DRIVER: Nenhuma notificação crítica no momento. Operação segura e blindada ativa.')}
            className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800 transition-colors cursor-pointer relative"
            title="Notificações da Central"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#b2ec5d]" />
          </button>

          <button
            onClick={() => setShowWBankModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#142607] hover:bg-[#1a330a] border border-[#a3e635]/40 text-[#a3e635] font-bold text-xs transition-colors shadow-sm cursor-pointer"
          >
            <Wallet className="w-4 h-4" />
            <span>W-BANK</span>
          </button>
        </div>
      </header>

      {/* NAVIGATION TABS (Direct match with the user's interactive prototype) */}
      <div className="bg-[#111611] border-b border-neutral-800 px-4 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar sticky top-[61px] z-30">
        <button
          onClick={() => setActiveTab('passageiro')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'passageiro'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>1. 📱 App Passageiro</span>
        </button>

        <button
          onClick={() => setActiveTab('cadastro')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'cadastro'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>2. 🛡️ Cadastro & Blindagem</span>
          {registration.status === 'em_analise' && (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          )}
        </button>

        <button
          onClick={() => {
            if (!currentRide) {
              handleProceedToPayment();
            } else {
              setActiveTab('pagamento');
            }
          }}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'pagamento'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span>3. 💳 PIX / QR Code</span>
          {currentRide?.status === 'aguardando_pix' && (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('central')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'central'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>4. 🏢 Central W-DRIVER</span>
          {allRides.some((r) => r.status === 'paga_central') && (
            <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('motorista')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'motorista'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <Radio className="w-3.5 h-3.5" />
          <span>5. 🏍️ App Motorista (Radar)</span>
        </button>

        <button
          onClick={() => setShowWBankModal(true)}
          className="px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap bg-neutral-900 text-emerald-400 hover:bg-neutral-800 transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <Wallet className="w-3.5 h-3.5" />
          <span>6. 🏦 W-BANK (90% Repasse)</span>
        </button>
      </div>

      {/* MAIN CONTENT WORKSPACE */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: ACTIVE SCREEN / WORKFLOW */}
        <div className="lg:col-span-8 w-full flex flex-col items-center">
          <DeviceFrame
            isMobileFrame={isMobileFrame}
            onToggleFrame={() => setIsMobileFrame(!isMobileFrame)}
          >
            {activeTab === 'passageiro' && (
              <PassengerApp
                origem={origem}
                setOrigem={setOrigem}
                destino={destino}
                setDestino={setDestino}
                distanciaKm={distanciaKm}
                setDistanciaKm={setDistanciaKm}
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
                surgeActive={surgeActive}
                setSurgeActive={setSurgeActive}
                onProceedToPayment={handleProceedToPayment}
              />
            )}

            {activeTab === 'cadastro' && (
              <div className="p-4 sm:p-6 w-full">
                <SecurityRegistration
                  registration={registration}
                  onUpdateRegistration={handleUpdateRegistration}
                  onGoToPassengerApp={() => setActiveTab('passageiro')}
                />
              </div>
            )}

            {activeTab === 'pagamento' && (
              <div className="p-4 sm:p-6 w-full">
                {currentRide ? (
                  <PixPaymentModal
                    ride={currentRide}
                    onPaymentSuccess={handlePaymentSuccess}
                    onBack={() => setActiveTab('passageiro')}
                  />
                ) : (
                  <div className="text-center p-8 bg-neutral-900 rounded-3xl border border-neutral-800">
                    <p className="text-xs text-neutral-400 mb-3">
                      Nenhuma corrida selecionada para pagamento no momento.
                    </p>
                    <button
                      onClick={() => setActiveTab('passageiro')}
                      className="px-4 py-2 rounded-xl bg-[#a3e635] text-neutral-950 font-bold text-xs"
                    >
                      Voltar ao App Passageiro
                    </button>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'central' && (
              <div className="p-4 sm:p-6 w-full">
                <CentralControl
                  rides={allRides}
                  onApproveAndDispatch={handleApproveAndDispatch}
                  onGoToDriverRadar={() => setActiveTab('motorista')}
                  surgeMultiplier={surgeMultiplier}
                  onChangeSurgeMultiplier={(val) => {
                    setSurgeMultiplier(val);
                    setSurgeActive(val > 1.0);
                  }}
                  registration={registration}
                  onUpdateRegistration={handleUpdateRegistration}
                />
              </div>
            )}

            {activeTab === 'motorista' && (
              <div className="p-4 sm:p-6 w-full">
                <DriverApp
                  activeRide={
                    allRides.find(
                      (r) =>
                        r.status === 'despachada' ||
                        r.status === 'motorista_a_caminho' ||
                        r.status === 'motorista_no_local' ||
                        r.status === 'em_viagem'
                    ) || null
                  }
                  surgeActive={surgeActive}
                  onToggleSurge={() => setSurgeActive(!surgeActive)}
                  onAcceptRide={handleAcceptRide}
                  onUpdateRideStatus={handleUpdateRideStatus}
                  onOpenWBank={() => setShowWBankModal(true)}
                />
              </div>
            )}
          </DeviceFrame>
        </div>

        {/* RIGHT COLUMN: TECHNICAL DIRECTIVES, ACTIVE SIMULATION SPECS & W-BANK OVERVIEW */}
        <div className="lg:col-span-4 w-full space-y-4">
          {/* Active Simulation Summary Card */}
          <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 shadow-xl space-y-4">
            <div className="flex items-center gap-2 border-b border-neutral-800 pb-3">
              <ShieldCheck className="w-5 h-5 text-[#a3e635]" />
              <div>
                <h2 className="text-sm font-black text-white">
                  Sistema Blindado W-DRIVER
                </h2>
                <span className="text-[10px] text-[#a3e635] font-semibold block">
                  Segurança Máxima Anti-Fraude e Anti-Calote
                </span>
              </div>
            </div>

            <ul className="space-y-3 text-xs text-neutral-300">
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">Biometria Facial & Prova de Vida:</strong>
                  Reconhecimento facial obrigatório de passageiros e motoristas para erradicar contas falsas e perfis fantasmas.
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">Antecedentes & Assinatura gov.br:</strong>
                  Checagem rigorosa de antecedentes criminais e autenticação jurídica com validade federal via gov.br.
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">Botão de Emergência W-SOS 24h:</strong>
                  Acionamento instantâneo com envio de telemetria, áudio ambiente e alerta prioritário para a Central e segurança pública.
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">Gravação 360° em No-Show:</strong>
                  Após 03:00 min de espera no local de embarque, o motorista grava evidência em 360° com crédito automático da taxa de deslocamento no W-BANK.
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">W-BANK (90% Repasse Líquido):</strong>
                  O motorista recebe 90% diretamente em sua conta digital W-BANK com transferência PIX imediata e proteção anti-calote.
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">Radar Dinâmico & Modo Táxi Inmetro:</strong>
                  Acréscimos proporcionais para valorizar o motorista e suporte ao Modo Táxi com medição por taxímetro regulamentado.
                </div>
              </li>
            </ul>
          </div>

          {/* Quick Tariff Breakdown Card */}
          <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
              <span className="text-xs font-bold text-white">Tabela de Tarifas Atuais</span>
              <span className="text-[10px] text-[#a3e635] font-semibold">Até 4km | Adicional</span>
            </div>

            <div className="space-y-1.5 text-xs">
              {CATEGORIES.slice(0, 6).map((cat) => (
                <div key={cat.id} className="flex justify-between items-center py-1 border-b border-neutral-800/40">
                  <span className="text-neutral-300 font-medium">{cat.name}</span>
                  <div className="text-right">
                    <span className="text-[#a3e635] font-bold">R$ {cat.baseFare.toFixed(2).replace('.', ',')}</span>
                    <span className="text-neutral-500 text-[10px] ml-1">
                      (+R$ {cat.kmAdicional.toFixed(2).replace('.', ',')}/km)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* W-BANK Quick Access Card */}
          <div
            onClick={() => setShowWBankModal(true)}
            className="p-5 rounded-3xl bg-gradient-to-br from-[#122407] to-[#0a1204] border border-[#a3e635]/30 cursor-pointer hover:border-[#a3e635] transition-all shadow-xl group"
          >
            <div className="flex items-center justify-between mb-2">
              <WDriverLogo variant="wbank" size="sm" />
              <span className="text-xs text-[#a3e635] group-hover:translate-x-1 transition-transform">➔</span>
            </div>
            <p className="text-xs text-neutral-300 mb-3">
              Abra a carteira digital para consultar saldo de repasses e efetuar transferências PIX instantâneas.
            </p>
            <div className="flex items-center justify-between text-xs font-bold text-white bg-black/40 p-2.5 rounded-xl border border-white/5">
              <span>Repasses Concluídos:</span>
              <span className="text-[#a3e635] font-black">{completedRides.length} corridas</span>
            </div>
          </div>
        </div>
      </main>

      {/* W-BANK DRAWER MODAL */}
      {showWBankModal && (
        <WBankDrawer
          onClose={() => setShowWBankModal(false)}
          completedRides={completedRides}
        />
      )}
    </div>
  );
}
