export type ServiceCategory = 
  | 'w_bike'
  | 'w_moto_comum'
  | 'w_moto_prime'
  | 'w_carro_comum'
  | 'w_carro_prime'
  | 'w_carro_exec_comum'
  | 'w_carro_exec_prime'
  | 'w_luxo'
  | 'taxi';

export interface CategoryInfo {
  id: ServiceCategory;
  name: string;
  subtitle: string;
  baseFare: number; // Tarifa fixa até 4km
  kmAdicional: number; // Por km excedente
  iconType: 'bike' | 'moto' | 'moto_prime' | 'car_white' | 'car_blue' | 'car_black' | 'car_exec' | 'luxury' | 'taxi';
  tag?: string;
  isContractOnly?: boolean;
  isTaxiMeter?: boolean;
  capacity: string;
  etaMins: number;
}

export type RideStatus = 
  | 'solicitada'
  | 'aguardando_pix'
  | 'paga_central'
  | 'despachada'
  | 'motorista_a_caminho'
  | 'motorista_no_local'
  | 'em_viagem'
  | 'concluida'
  | 'cancelada';

export interface RideData {
  id: string;
  origem: string;
  origemBairro: string;
  destino: string;
  destinoBairro: string;
  distanciaKm: number;
  tempoEstimadoMin: number;
  categoria: CategoryInfo;
  valorBase: number;
  dinamicaAtiva: boolean;
  multiplicadorDinamica: number;
  valorTotal: number;
  repasseMotorista: number; // 90%
  taxaPlataforma: number; // 10%
  status: RideStatus;
  criadoEm: string;
  chavePix: string;
  codigoPix: string;
  passageiroNome: string;
  motoristaNome?: string;
  motoristaVeiculo?: string;
  motoristaPlaca?: string;
}

export type ActiveTab = 'passageiro' | 'cadastro' | 'pagamento' | 'central' | 'motorista' | 'wbank';

export type RegistrationStatus = 'nao_iniciado' | 'em_analise' | 'aprovado' | 'bloqueado';

export interface UserRegistration {
  nome: string;
  cpf: string;
  telefone: string;
  naturalidade: string;
  selfieEnviada: boolean;
  documentoEnviado: boolean;
  antecedentesEnviados: boolean;
  govBrAssinado: boolean;
  termosAceitos: boolean;
  status: RegistrationStatus;
  dataSubmissao?: string;
}
